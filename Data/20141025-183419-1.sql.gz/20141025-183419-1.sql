-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : one
-- 
-- Part : #1
-- Date : 2014-10-25 18:34:20
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `m_iplistener`
-- -----------------------------
DROP TABLE IF EXISTS `m_iplistener`;
CREATE TABLE `m_iplistener` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(64) NOT NULL COMMENT 'ip地址',
  `visit_time` varchar(16) NOT NULL COMMENT '访问时间',
  `visit_url` varchar(256) NOT NULL COMMENT '访问地址',
  `city` varchar(32) NOT NULL COMMENT '地理位置',
  `isp` varchar(16) NOT NULL COMMENT '运营商',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `onethink_action`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_action`;
CREATE TABLE `onethink_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `onethink_action`
-- -----------------------------
INSERT INTO `onethink_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `onethink_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `onethink_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `onethink_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。
表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `onethink_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `onethink_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `onethink_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `onethink_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `onethink_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `onethink_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `onethink_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');

-- -----------------------------
-- Table structure for `onethink_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_action_log`;
CREATE TABLE `onethink_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=472 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `onethink_action_log`
-- -----------------------------
INSERT INTO `onethink_action_log` VALUES ('1', '1', '1', '2130706433', 'member', '1', '123在2014-09-02 23:18登录了后台', '1', '1409671080');
INSERT INTO `onethink_action_log` VALUES ('2', '1', '1', '2130706433', 'member', '1', '123在2014-09-08 00:14登录了后台', '1', '1410106475');
INSERT INTO `onethink_action_log` VALUES ('3', '7', '1', '2130706433', 'model', '4', '操作url：/111/ADMIN.php?s=/Model/update.html', '1', '1410106601');
INSERT INTO `onethink_action_log` VALUES ('4', '1', '1', '2130706433', 'member', '1', '123在2014-09-18 04:08登录了后台', '1', '1410984501');
INSERT INTO `onethink_action_log` VALUES ('5', '11', '1', '2130706433', 'category', '39', '操作url：/111/ADMIN.php?s=/Category/add.html', '1', '1410984635');
INSERT INTO `onethink_action_log` VALUES ('6', '1', '1', '2130706433', 'member', '1', '123在2014-09-22 04:36登录了后台', '1', '1411331788');
INSERT INTO `onethink_action_log` VALUES ('7', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411331932');
INSERT INTO `onethink_action_log` VALUES ('8', '11', '1', '2130706433', 'category', '41', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411332731');
INSERT INTO `onethink_action_log` VALUES ('9', '11', '1', '2130706433', 'category', '42', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411332913');
INSERT INTO `onethink_action_log` VALUES ('10', '11', '1', '2130706433', 'category', '43', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411332994');
INSERT INTO `onethink_action_log` VALUES ('11', '11', '1', '2130706433', 'category', '44', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411333039');
INSERT INTO `onethink_action_log` VALUES ('12', '11', '1', '2130706433', 'category', '45', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411333095');
INSERT INTO `onethink_action_log` VALUES ('13', '11', '1', '2130706433', 'category', '42', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411333193');
INSERT INTO `onethink_action_log` VALUES ('14', '11', '1', '2130706433', 'category', '41', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411333565');
INSERT INTO `onethink_action_log` VALUES ('15', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411333567');
INSERT INTO `onethink_action_log` VALUES ('16', '11', '1', '2130706433', 'category', '41', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411333573');
INSERT INTO `onethink_action_log` VALUES ('17', '11', '1', '2130706433', 'category', '42', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411333575');
INSERT INTO `onethink_action_log` VALUES ('18', '11', '1', '2130706433', 'category', '43', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411333577');
INSERT INTO `onethink_action_log` VALUES ('19', '11', '1', '2130706433', 'category', '44', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411333580');
INSERT INTO `onethink_action_log` VALUES ('20', '11', '1', '2130706433', 'category', '45', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411333586');
INSERT INTO `onethink_action_log` VALUES ('21', '8', '1', '2130706433', 'attribute', '34', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411374886');
INSERT INTO `onethink_action_log` VALUES ('22', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1411375498');
INSERT INTO `onethink_action_log` VALUES ('23', '11', '1', '2130706433', 'category', '41', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411375696');
INSERT INTO `onethink_action_log` VALUES ('24', '8', '1', '2130706433', 'attribute', '35', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411375944');
INSERT INTO `onethink_action_log` VALUES ('25', '8', '1', '2130706433', 'attribute', '34', '操作url：/111/admin.php?s=/Attribute/remove/id/34.html', '1', '1411376099');
INSERT INTO `onethink_action_log` VALUES ('26', '8', '1', '2130706433', 'attribute', '36', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411376156');
INSERT INTO `onethink_action_log` VALUES ('27', '11', '1', '2130706433', 'category', '41', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411378454');
INSERT INTO `onethink_action_log` VALUES ('28', '7', '1', '2130706433', 'model', '6', '操作url：/111/admin.php?s=/Model/update.html', '1', '1411379238');
INSERT INTO `onethink_action_log` VALUES ('29', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1411379419');
INSERT INTO `onethink_action_log` VALUES ('30', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1411379602');
INSERT INTO `onethink_action_log` VALUES ('31', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1411379750');
INSERT INTO `onethink_action_log` VALUES ('32', '8', '1', '2130706433', 'attribute', '37', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411379961');
INSERT INTO `onethink_action_log` VALUES ('33', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1411379979');
INSERT INTO `onethink_action_log` VALUES ('34', '8', '1', '2130706433', 'attribute', '38', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411380076');
INSERT INTO `onethink_action_log` VALUES ('35', '8', '1', '2130706433', 'attribute', '39', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411380147');
INSERT INTO `onethink_action_log` VALUES ('36', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1411380235');
INSERT INTO `onethink_action_log` VALUES ('37', '11', '1', '2130706433', 'category', '42', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411423736');
INSERT INTO `onethink_action_log` VALUES ('38', '11', '1', '2130706433', 'category', '42', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411423791');
INSERT INTO `onethink_action_log` VALUES ('39', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411423874');
INSERT INTO `onethink_action_log` VALUES ('40', '11', '1', '2130706433', 'category', '43', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411423971');
INSERT INTO `onethink_action_log` VALUES ('41', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411423989');
INSERT INTO `onethink_action_log` VALUES ('42', '11', '1', '2130706433', 'category', '42', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411426189');
INSERT INTO `onethink_action_log` VALUES ('43', '8', '1', '2130706433', 'attribute', '37', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411430267');
INSERT INTO `onethink_action_log` VALUES ('44', '8', '1', '2130706433', 'attribute', '35', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411430769');
INSERT INTO `onethink_action_log` VALUES ('45', '1', '1', '2130706433', 'member', '1', '123在2014-09-24 20:31登录了后台', '1', '1411561881');
INSERT INTO `onethink_action_log` VALUES ('46', '1', '1', '2130706433', 'member', '1', '123在2014-09-25 02:21登录了后台', '1', '1411582899');
INSERT INTO `onethink_action_log` VALUES ('47', '1', '1', '2130706433', 'member', '1', '123在2014-09-25 02:22登录了后台', '1', '1411582952');
INSERT INTO `onethink_action_log` VALUES ('48', '1', '1', '2130706433', 'member', '1', '123在2014-09-25 02:45登录了后台', '1', '1411584334');
INSERT INTO `onethink_action_log` VALUES ('49', '1', '1', '2130706433', 'member', '1', '123在2014-09-25 03:49登录了后台', '1', '1411588140');
INSERT INTO `onethink_action_log` VALUES ('50', '1', '1', '2130706433', 'member', '1', '123在2014-09-25 03:50登录了后台', '1', '1411588205');
INSERT INTO `onethink_action_log` VALUES ('51', '1', '1', '2130706433', 'member', '1', '123在2014-09-25 04:49登录了后台', '1', '1411591763');
INSERT INTO `onethink_action_log` VALUES ('52', '1', '1', '2130706433', 'member', '1', '123在2014-09-25 07:26登录了后台', '1', '1411601185');
INSERT INTO `onethink_action_log` VALUES ('53', '9', '1', '2130706433', 'channel', '4', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1411601218');
INSERT INTO `onethink_action_log` VALUES ('54', '10', '1', '2130706433', 'Menu', '68', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1411626093');
INSERT INTO `onethink_action_log` VALUES ('55', '10', '1', '2130706433', 'Menu', '2', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1411626108');
INSERT INTO `onethink_action_log` VALUES ('56', '10', '1', '2130706433', 'Menu', '123', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1411626231');
INSERT INTO `onethink_action_log` VALUES ('57', '1', '1', '2130706433', 'member', '1', '123在2014-09-25 14:59登录了后台', '1', '1411628369');
INSERT INTO `onethink_action_log` VALUES ('58', '10', '1', '2130706433', 'Menu', '123', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1411628417');
INSERT INTO `onethink_action_log` VALUES ('59', '1', '1', '2130706433', 'member', '1', '123在2014-09-25 15:01登录了后台', '1', '1411628481');
INSERT INTO `onethink_action_log` VALUES ('60', '10', '1', '2130706433', 'Menu', '123', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1411628579');
INSERT INTO `onethink_action_log` VALUES ('61', '10', '1', '2130706433', 'Menu', '123', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1411628597');
INSERT INTO `onethink_action_log` VALUES ('62', '1', '1', '2130706433', 'member', '1', '123在2014-09-25 15:04登录了后台', '1', '1411628669');
INSERT INTO `onethink_action_log` VALUES ('63', '10', '1', '2130706433', 'Menu', '123', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1411628714');
INSERT INTO `onethink_action_log` VALUES ('64', '1', '1', '2130706433', 'member', '1', '123在2014-09-25 16:27登录了后台', '1', '1411633675');
INSERT INTO `onethink_action_log` VALUES ('65', '6', '1', '2130706433', 'config', '13', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1411636345');
INSERT INTO `onethink_action_log` VALUES ('66', '6', '1', '2130706433', 'config', '13', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1411636374');
INSERT INTO `onethink_action_log` VALUES ('67', '6', '1', '2130706433', 'config', '13', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1411636415');
INSERT INTO `onethink_action_log` VALUES ('68', '1', '1', '2130706433', 'member', '1', '123在2014-09-26 01:19登录了后台', '1', '1411665548');
INSERT INTO `onethink_action_log` VALUES ('69', '1', '1', '2130706433', 'member', '1', '123在2014-09-26 02:03登录了后台', '1', '1411668230');
INSERT INTO `onethink_action_log` VALUES ('70', '1', '1', '2130706433', 'member', '1', '123在2014-09-26 02:19登录了后台', '1', '1411669153');
INSERT INTO `onethink_action_log` VALUES ('71', '1', '1', '2130706433', 'member', '1', '123在2014-09-26 16:14登录了后台', '1', '1411719268');
INSERT INTO `onethink_action_log` VALUES ('72', '1', '1', '2130706433', 'member', '1', '123在2014-09-26 23:17登录了后台', '1', '1411744638');
INSERT INTO `onethink_action_log` VALUES ('73', '11', '1', '2130706433', 'category', '46', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411753883');
INSERT INTO `onethink_action_log` VALUES ('74', '8', '1', '2130706433', 'attribute', '40', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411815168');
INSERT INTO `onethink_action_log` VALUES ('75', '8', '1', '2130706433', 'attribute', '41', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411815490');
INSERT INTO `onethink_action_log` VALUES ('76', '1', '1', '2130706433', 'member', '1', '123在2014-09-28 02:38登录了后台', '1', '1411843139');
INSERT INTO `onethink_action_log` VALUES ('77', '1', '1', '2130706433', 'member', '1', '123在2014-09-28 16:21登录了后台', '1', '1411892476');
INSERT INTO `onethink_action_log` VALUES ('78', '1', '1', '2130706433', 'member', '1', '123在2014-09-28 23:43登录了后台', '1', '1411919024');
INSERT INTO `onethink_action_log` VALUES ('79', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411919124');
INSERT INTO `onethink_action_log` VALUES ('80', '11', '1', '2130706433', 'category', '46', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411919165');
INSERT INTO `onethink_action_log` VALUES ('81', '11', '1', '2130706433', 'category', '46', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411919196');
INSERT INTO `onethink_action_log` VALUES ('82', '11', '1', '2130706433', 'category', '47', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411919513');
INSERT INTO `onethink_action_log` VALUES ('83', '8', '1', '2130706433', 'attribute', '42', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411919829');
INSERT INTO `onethink_action_log` VALUES ('84', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1411919968');
INSERT INTO `onethink_action_log` VALUES ('85', '11', '1', '2130706433', 'category', '47', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411919985');
INSERT INTO `onethink_action_log` VALUES ('86', '11', '1', '2130706433', 'category', '47', '操作url：/111/admin.php?s=/Category/remove/id/47.html', '1', '1411921851');
INSERT INTO `onethink_action_log` VALUES ('87', '11', '1', '2130706433', 'category', '46', '操作url：/111/admin.php?s=/Category/remove/id/46.html', '1', '1411921855');
INSERT INTO `onethink_action_log` VALUES ('88', '11', '1', '2130706433', 'category', '48', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411921891');
INSERT INTO `onethink_action_log` VALUES ('89', '11', '1', '2130706433', 'category', '49', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411921928');
INSERT INTO `onethink_action_log` VALUES ('90', '11', '1', '2130706433', 'category', '48', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411922379');
INSERT INTO `onethink_action_log` VALUES ('91', '11', '1', '2130706433', 'category', '49', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411922398');
INSERT INTO `onethink_action_log` VALUES ('92', '11', '1', '2130706433', 'category', '48', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411922408');
INSERT INTO `onethink_action_log` VALUES ('93', '11', '1', '2130706433', 'category', '48', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411922447');
INSERT INTO `onethink_action_log` VALUES ('94', '11', '1', '2130706433', 'category', '48', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411922468');
INSERT INTO `onethink_action_log` VALUES ('95', '11', '1', '2130706433', 'category', '49', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411922494');
INSERT INTO `onethink_action_log` VALUES ('96', '11', '1', '2130706433', 'category', '48', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411922521');
INSERT INTO `onethink_action_log` VALUES ('97', '11', '1', '2130706433', 'category', '49', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411922533');
INSERT INTO `onethink_action_log` VALUES ('98', '11', '1', '2130706433', 'category', '49', '操作url：/111/admin.php?s=/Category/remove/id/49.html', '1', '1411922561');
INSERT INTO `onethink_action_log` VALUES ('99', '11', '1', '2130706433', 'category', '50', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411922581');
INSERT INTO `onethink_action_log` VALUES ('100', '11', '1', '2130706433', 'category', '50', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411922589');
INSERT INTO `onethink_action_log` VALUES ('101', '11', '1', '2130706433', 'category', '51', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411922681');
INSERT INTO `onethink_action_log` VALUES ('102', '11', '1', '2130706433', 'category', '48', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411924257');
INSERT INTO `onethink_action_log` VALUES ('103', '11', '1', '2130706433', 'category', '51', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411924262');
INSERT INTO `onethink_action_log` VALUES ('104', '11', '1', '2130706433', 'category', '50', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411924275');
INSERT INTO `onethink_action_log` VALUES ('105', '11', '1', '2130706433', 'category', '51', '操作url：/111/admin.php?s=/Category/remove/id/51.html', '1', '1411924303');
INSERT INTO `onethink_action_log` VALUES ('106', '11', '1', '2130706433', 'category', '50', '操作url：/111/admin.php?s=/Category/remove/id/50.html', '1', '1411924306');
INSERT INTO `onethink_action_log` VALUES ('107', '11', '1', '2130706433', 'category', '48', '操作url：/111/admin.php?s=/Category/remove/id/48.html', '1', '1411924311');
INSERT INTO `onethink_action_log` VALUES ('108', '11', '1', '2130706433', 'category', '52', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411925214');
INSERT INTO `onethink_action_log` VALUES ('109', '11', '1', '2130706433', 'category', '53', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411925256');
INSERT INTO `onethink_action_log` VALUES ('110', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411925311');
INSERT INTO `onethink_action_log` VALUES ('111', '11', '1', '2130706433', 'category', '52', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411925343');
INSERT INTO `onethink_action_log` VALUES ('112', '11', '1', '2130706433', 'category', '53', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411925363');
INSERT INTO `onethink_action_log` VALUES ('113', '11', '1', '2130706433', 'category', '54', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411925757');
INSERT INTO `onethink_action_log` VALUES ('114', '11', '1', '2130706433', 'category', '54', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411925795');
INSERT INTO `onethink_action_log` VALUES ('115', '11', '1', '2130706433', 'category', '54', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411925813');
INSERT INTO `onethink_action_log` VALUES ('116', '11', '1', '2130706433', 'category', '54', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411926068');
INSERT INTO `onethink_action_log` VALUES ('117', '11', '1', '2130706433', 'category', '54', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411926113');
INSERT INTO `onethink_action_log` VALUES ('118', '11', '1', '2130706433', 'category', '55', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411926230');
INSERT INTO `onethink_action_log` VALUES ('119', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1411927705');
INSERT INTO `onethink_action_log` VALUES ('120', '8', '1', '2130706433', 'attribute', '37', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1411927788');
INSERT INTO `onethink_action_log` VALUES ('121', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1411928512');
INSERT INTO `onethink_action_log` VALUES ('122', '11', '1', '2130706433', 'category', '56', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411929200');
INSERT INTO `onethink_action_log` VALUES ('123', '11', '1', '2130706433', 'category', '56', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411929233');
INSERT INTO `onethink_action_log` VALUES ('124', '11', '1', '2130706433', 'category', '57', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411934874');
INSERT INTO `onethink_action_log` VALUES ('125', '11', '1', '2130706433', 'category', '57', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1411934898');
INSERT INTO `onethink_action_log` VALUES ('126', '11', '1', '2130706433', 'category', '58', '操作url：/111/admin.php?s=/Category/add.html', '1', '1411935041');
INSERT INTO `onethink_action_log` VALUES ('127', '1', '1', '2130706433', 'member', '1', '123在2014-09-30 02:37登录了后台', '1', '1412015859');
INSERT INTO `onethink_action_log` VALUES ('128', '8', '1', '2130706433', 'attribute', '43', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1412016195');
INSERT INTO `onethink_action_log` VALUES ('129', '8', '1', '2130706433', 'attribute', '43', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1412016226');
INSERT INTO `onethink_action_log` VALUES ('130', '8', '1', '2130706433', 'attribute', '43', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1412016261');
INSERT INTO `onethink_action_log` VALUES ('131', '1', '1', '2130706433', 'member', '1', '123在2014-10-03 00:06登录了后台', '1', '1412265970');
INSERT INTO `onethink_action_log` VALUES ('132', '1', '1', '2130706433', 'member', '1', '123在2014-10-04 02:48登录了后台', '1', '1412362117');
INSERT INTO `onethink_action_log` VALUES ('133', '1', '1', '2130706433', 'member', '1', '123在2014-10-05 04:28登录了后台', '1', '1412454508');
INSERT INTO `onethink_action_log` VALUES ('134', '10', '1', '2130706433', 'Menu', '123', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412500356');
INSERT INTO `onethink_action_log` VALUES ('135', '10', '1', '2130706433', 'Menu', '123', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412500415');
INSERT INTO `onethink_action_log` VALUES ('136', '10', '1', '2130706433', 'Menu', '68', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412500473');
INSERT INTO `onethink_action_log` VALUES ('137', '1', '1', '2130706433', 'member', '1', '123在2014-10-05 17:15登录了后台', '1', '1412500510');
INSERT INTO `onethink_action_log` VALUES ('138', '1', '1', '2130706433', 'member', '1', '123在2014-10-05 17:17登录了后台', '1', '1412500625');
INSERT INTO `onethink_action_log` VALUES ('139', '1', '1', '2130706433', 'member', '1', '123在2014-10-05 17:31登录了后台', '1', '1412501476');
INSERT INTO `onethink_action_log` VALUES ('140', '10', '1', '2130706433', 'Menu', '124', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1412501560');
INSERT INTO `onethink_action_log` VALUES ('141', '1', '1', '2130706433', 'member', '1', '123在2014-10-05 17:32登录了后台', '1', '1412501577');
INSERT INTO `onethink_action_log` VALUES ('142', '10', '1', '2130706433', 'Menu', '124', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412501609');
INSERT INTO `onethink_action_log` VALUES ('143', '10', '1', '2130706433', 'Menu', '124', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412501665');
INSERT INTO `onethink_action_log` VALUES ('144', '1', '1', '2130706433', 'member', '1', '123在2014-10-05 17:34登录了后台', '1', '1412501697');
INSERT INTO `onethink_action_log` VALUES ('145', '10', '1', '2130706433', 'Menu', '124', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412504980');
INSERT INTO `onethink_action_log` VALUES ('146', '1', '1', '2130706433', 'member', '1', '123在2014-10-05 18:31登录了后台', '1', '1412505074');
INSERT INTO `onethink_action_log` VALUES ('147', '11', '1', '2130706433', 'category', '41', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412505916');
INSERT INTO `onethink_action_log` VALUES ('148', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412505960');
INSERT INTO `onethink_action_log` VALUES ('149', '11', '1', '2130706433', 'category', '42', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412505968');
INSERT INTO `onethink_action_log` VALUES ('150', '11', '1', '2130706433', 'category', '43', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506328');
INSERT INTO `onethink_action_log` VALUES ('151', '11', '1', '2130706433', 'category', '44', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506337');
INSERT INTO `onethink_action_log` VALUES ('152', '11', '1', '2130706433', 'category', '56', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506344');
INSERT INTO `onethink_action_log` VALUES ('153', '11', '1', '2130706433', 'category', '41', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506353');
INSERT INTO `onethink_action_log` VALUES ('154', '11', '1', '2130706433', 'category', '42', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506361');
INSERT INTO `onethink_action_log` VALUES ('155', '11', '1', '2130706433', 'category', '43', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506370');
INSERT INTO `onethink_action_log` VALUES ('156', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506407');
INSERT INTO `onethink_action_log` VALUES ('157', '11', '1', '2130706433', 'category', '42', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506417');
INSERT INTO `onethink_action_log` VALUES ('158', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506491');
INSERT INTO `onethink_action_log` VALUES ('159', '11', '1', '2130706433', 'category', '41', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506502');
INSERT INTO `onethink_action_log` VALUES ('160', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506518');
INSERT INTO `onethink_action_log` VALUES ('161', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506774');
INSERT INTO `onethink_action_log` VALUES ('162', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506796');
INSERT INTO `onethink_action_log` VALUES ('163', '11', '1', '2130706433', 'category', '41', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412506808');
INSERT INTO `onethink_action_log` VALUES ('164', '11', '1', '2130706433', 'category', '59', '操作url：/111/admin.php?s=/Category/add.html', '1', '1412506827');
INSERT INTO `onethink_action_log` VALUES ('165', '11', '1', '2130706433', 'category', '60', '操作url：/111/admin.php?s=/Category/add.html', '1', '1412506837');
INSERT INTO `onethink_action_log` VALUES ('166', '11', '1', '2130706433', 'category', '59', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412507664');
INSERT INTO `onethink_action_log` VALUES ('167', '11', '1', '2130706433', 'category', '56', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412511381');
INSERT INTO `onethink_action_log` VALUES ('168', '11', '1', '2130706433', 'category', '56', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412511406');
INSERT INTO `onethink_action_log` VALUES ('169', '11', '1', '2130706433', 'category', '56', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412511425');
INSERT INTO `onethink_action_log` VALUES ('170', '1', '1', '2130706433', 'member', '1', '123在2014-10-05 23:28登录了后台', '1', '1412522903');
INSERT INTO `onethink_action_log` VALUES ('171', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412522930');
INSERT INTO `onethink_action_log` VALUES ('172', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412523224');
INSERT INTO `onethink_action_log` VALUES ('173', '11', '1', '2130706433', 'category', '41', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412523475');
INSERT INTO `onethink_action_log` VALUES ('174', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412523482');
INSERT INTO `onethink_action_log` VALUES ('175', '11', '1', '2130706433', 'category', '42', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412523532');
INSERT INTO `onethink_action_log` VALUES ('176', '11', '1', '2130706433', 'category', '43', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412523540');
INSERT INTO `onethink_action_log` VALUES ('177', '11', '1', '2130706433', 'category', '44', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412523548');
INSERT INTO `onethink_action_log` VALUES ('178', '11', '1', '2130706433', 'category', '45', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412523556');
INSERT INTO `onethink_action_log` VALUES ('179', '11', '1', '2130706433', 'category', '52', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412523588');
INSERT INTO `onethink_action_log` VALUES ('180', '11', '1', '2130706433', 'category', '60', '操作url：/111/admin.php?s=/Category/remove/id/60.html', '1', '1412523594');
INSERT INTO `onethink_action_log` VALUES ('181', '11', '1', '2130706433', 'category', '59', '操作url：/111/admin.php?s=/Category/remove/id/59.html', '1', '1412523600');
INSERT INTO `onethink_action_log` VALUES ('182', '11', '1', '2130706433', 'category', '58', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412523617');
INSERT INTO `onethink_action_log` VALUES ('183', '11', '1', '2130706433', 'category', '57', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412523627');
INSERT INTO `onethink_action_log` VALUES ('184', '11', '1', '2130706433', 'category', '53', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412523640');
INSERT INTO `onethink_action_log` VALUES ('185', '10', '1', '2130706433', 'Menu', '124', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412527179');
INSERT INTO `onethink_action_log` VALUES ('186', '1', '1', '2130706433', 'member', '1', '123在2014-10-06 00:40登录了后台', '1', '1412527213');
INSERT INTO `onethink_action_log` VALUES ('187', '1', '1', '2130706433', 'member', '1', '123在2014-10-06 02:10登录了后台', '1', '1412532625');
INSERT INTO `onethink_action_log` VALUES ('188', '1', '1', '2130706433', 'member', '1', '123在2014-10-06 14:32登录了后台', '1', '1412577125');
INSERT INTO `onethink_action_log` VALUES ('189', '6', '1', '2130706433', 'config', '1', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1412577188');
INSERT INTO `onethink_action_log` VALUES ('190', '6', '1', '2130706433', 'config', '1', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1412577236');
INSERT INTO `onethink_action_log` VALUES ('191', '6', '1', '2130706433', 'config', '1', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1412577255');
INSERT INTO `onethink_action_log` VALUES ('192', '9', '1', '2130706433', 'channel', '1', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1412577610');
INSERT INTO `onethink_action_log` VALUES ('193', '9', '1', '2130706433', 'channel', '3', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1412578762');
INSERT INTO `onethink_action_log` VALUES ('194', '9', '1', '2130706433', 'channel', '3', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1412578852');
INSERT INTO `onethink_action_log` VALUES ('195', '9', '1', '2130706433', 'channel', '1', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1412578881');
INSERT INTO `onethink_action_log` VALUES ('196', '9', '1', '2130706433', 'channel', '1', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1412579864');
INSERT INTO `onethink_action_log` VALUES ('197', '9', '1', '2130706433', 'channel', '0', '操作url：/111/admin.php?s=/Channel/del/id/2.html', '1', '1412584404');
INSERT INTO `onethink_action_log` VALUES ('198', '1', '1', '2130706433', 'member', '1', '123在2014-10-06 17:17登录了后台', '1', '1412587051');
INSERT INTO `onethink_action_log` VALUES ('199', '10', '1', '2130706433', 'Menu', '125', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1412587202');
INSERT INTO `onethink_action_log` VALUES ('200', '10', '1', '2130706433', 'Menu', '0', '操作url：/111/admin.php?s=/Menu/del/id/125.html', '1', '1412587222');
INSERT INTO `onethink_action_log` VALUES ('201', '10', '1', '2130706433', 'Menu', '126', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1412588190');
INSERT INTO `onethink_action_log` VALUES ('202', '10', '1', '2130706433', 'Menu', '0', '操作url：/111/admin.php?s=/Menu/del.html', '1', '1412588196');
INSERT INTO `onethink_action_log` VALUES ('203', '10', '1', '2130706433', 'Menu', '63', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412588545');
INSERT INTO `onethink_action_log` VALUES ('204', '10', '1', '2130706433', 'Menu', '127', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1412588617');
INSERT INTO `onethink_action_log` VALUES ('205', '1', '1', '2130706433', 'member', '1', '123在2014-10-06 17:47登录了后台', '1', '1412588848');
INSERT INTO `onethink_action_log` VALUES ('206', '10', '1', '2130706433', 'Menu', '124', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412589112');
INSERT INTO `onethink_action_log` VALUES ('207', '10', '1', '2130706433', 'Menu', '0', '操作url：/111/admin.php?s=/Menu/del/id/127.html', '1', '1412589135');
INSERT INTO `onethink_action_log` VALUES ('208', '10', '1', '2130706433', 'Menu', '128', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1412591408');
INSERT INTO `onethink_action_log` VALUES ('209', '10', '1', '2130706433', 'Menu', '0', '操作url：/111/admin.php?s=/Menu/del/id/128.html', '1', '1412591430');
INSERT INTO `onethink_action_log` VALUES ('210', '9', '1', '2130706433', 'channel', '0', '操作url：/111/admin.php?s=/Channel/del/id/6.html', '1', '1412593847');
INSERT INTO `onethink_action_log` VALUES ('211', '6', '1', '2130706433', 'config', '0', '操作url：/111/admin.php?s=/Config/del.html', '1', '1412598602');
INSERT INTO `onethink_action_log` VALUES ('212', '10', '1', '2130706433', 'Menu', '124', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412600149');
INSERT INTO `onethink_action_log` VALUES ('213', '1', '1', '2130706433', 'member', '1', '123在2014-10-06 20:56登录了后台', '1', '1412600214');
INSERT INTO `onethink_action_log` VALUES ('214', '10', '1', '2130706433', 'Menu', '124', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412606999');
INSERT INTO `onethink_action_log` VALUES ('215', '10', '1', '2130706433', 'Menu', '129', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1412607070');
INSERT INTO `onethink_action_log` VALUES ('216', '10', '1', '2130706433', 'Menu', '129', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412607102');
INSERT INTO `onethink_action_log` VALUES ('217', '1', '1', '2130706433', 'member', '1', '123在2014-10-06 22:52登录了后台', '1', '1412607159');
INSERT INTO `onethink_action_log` VALUES ('218', '10', '1', '2130706433', 'Menu', '129', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412610768');
INSERT INTO `onethink_action_log` VALUES ('219', '1', '1', '2130706433', 'member', '1', '123在2014-10-07 00:22登录了后台', '1', '1412612553');
INSERT INTO `onethink_action_log` VALUES ('220', '1', '1', '2130706433', 'member', '1', '123在2014-10-07 00:41登录了后台', '1', '1412613698');
INSERT INTO `onethink_action_log` VALUES ('221', '1', '1', '2130706433', 'member', '1', '123在2014-10-07 01:23登录了后台', '1', '1412616183');
INSERT INTO `onethink_action_log` VALUES ('222', '1', '1', '2130706433', 'member', '1', '123在2014-10-08 01:21登录了后台', '1', '1412702480');
INSERT INTO `onethink_action_log` VALUES ('223', '1', '1', '2130706433', 'member', '1', '123在2014-10-08 01:28登录了后台', '1', '1412702901');
INSERT INTO `onethink_action_log` VALUES ('224', '1', '1', '2130706433', 'member', '1', '123在2014-10-08 02:17登录了后台', '1', '1412705851');
INSERT INTO `onethink_action_log` VALUES ('225', '1', '1', '2130706433', 'member', '1', '123在2014-10-08 19:51登录了后台', '1', '1412769119');
INSERT INTO `onethink_action_log` VALUES ('226', '1', '1', '2130706433', 'member', '1', '123在2014-10-08 23:48登录了后台', '1', '1412783304');
INSERT INTO `onethink_action_log` VALUES ('227', '1', '1', '2130706433', 'member', '1', '123在2014-10-09 00:00登录了后台', '1', '1412784033');
INSERT INTO `onethink_action_log` VALUES ('228', '1', '1', '2130706433', 'member', '1', '123在2014-10-09 03:34登录了后台', '1', '1412796848');
INSERT INTO `onethink_action_log` VALUES ('229', '1', '1', '2130706433', 'member', '1', '123在2014-10-09 04:00登录了后台', '1', '1412798448');
INSERT INTO `onethink_action_log` VALUES ('230', '1', '1', '2130706433', 'member', '1', '123在2014-10-09 15:15登录了后台', '1', '1412838955');
INSERT INTO `onethink_action_log` VALUES ('231', '1', '1', '2130706433', 'member', '1', '123在2014-10-09 20:03登录了后台', '1', '1412856232');
INSERT INTO `onethink_action_log` VALUES ('232', '11', '1', '2130706433', 'category', '52', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1412857931');
INSERT INTO `onethink_action_log` VALUES ('233', '11', '1', '2130706433', 'category', '61', '操作url：/111/admin.php?s=/Category/add.html', '1', '1412858684');
INSERT INTO `onethink_action_log` VALUES ('234', '11', '1', '2130706433', 'category', '62', '操作url：/111/admin.php?s=/Category/add.html', '1', '1412858876');
INSERT INTO `onethink_action_log` VALUES ('235', '1', '1', '2130706433', 'member', '1', '123在2014-10-09 21:34登录了后台', '1', '1412861645');
INSERT INTO `onethink_action_log` VALUES ('236', '1', '1', '2130706433', 'member', '1', '123在2014-10-09 21:36登录了后台', '1', '1412861771');
INSERT INTO `onethink_action_log` VALUES ('237', '1', '1', '2130706433', 'member', '1', '123在2014-10-09 21:36登录了后台', '1', '1412861786');
INSERT INTO `onethink_action_log` VALUES ('238', '1', '1', '2130706433', 'member', '1', '123在2014-10-09 22:13登录了后台', '1', '1412863988');
INSERT INTO `onethink_action_log` VALUES ('239', '1', '1', '2130706433', 'member', '1', '123在2014-10-09 23:06登录了后台', '1', '1412867214');
INSERT INTO `onethink_action_log` VALUES ('240', '1', '1', '2130706433', 'member', '1', '123在2014-10-10 00:31登录了后台', '1', '1412872299');
INSERT INTO `onethink_action_log` VALUES ('241', '10', '1', '2130706433', 'Menu', '130', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1412872361');
INSERT INTO `onethink_action_log` VALUES ('242', '10', '1', '2130706433', 'Menu', '130', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1412872418');
INSERT INTO `onethink_action_log` VALUES ('243', '10', '1', '2130706433', 'Menu', '0', '操作url：/111/admin.php?s=/Menu/del/id/130.html', '1', '1412872440');
INSERT INTO `onethink_action_log` VALUES ('244', '9', '1', '2130706433', 'channel', '8', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1412872516');
INSERT INTO `onethink_action_log` VALUES ('245', '9', '1', '2130706433', 'channel', '8', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1412872673');
INSERT INTO `onethink_action_log` VALUES ('246', '9', '1', '2130706433', 'channel', '8', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1412872772');
INSERT INTO `onethink_action_log` VALUES ('247', '1', '1', '2130706433', 'member', '1', '123在2014-10-11 05:09登录了后台', '1', '1412975372');
INSERT INTO `onethink_action_log` VALUES ('248', '11', '1', '2130706433', 'category', '63', '操作url：/111/admin.php?s=/Category/add.html', '1', '1413019132');
INSERT INTO `onethink_action_log` VALUES ('249', '11', '1', '2130706433', 'category', '63', '操作url：/111/admin.php?s=/Category/remove/id/63.html', '1', '1413019167');
INSERT INTO `onethink_action_log` VALUES ('250', '1', '1', '2130706433', 'member', '1', '123在2014-10-11 22:06登录了后台', '1', '1413036365');
INSERT INTO `onethink_action_log` VALUES ('251', '1', '1', '2130706433', 'member', '1', '123在2014-10-13 15:56登录了后台', '1', '1413186968');
INSERT INTO `onethink_action_log` VALUES ('252', '1', '1', '2130706433', 'member', '1', '123在2014-10-13 18:30登录了后台', '1', '1413196243');
INSERT INTO `onethink_action_log` VALUES ('253', '11', '1', '2130706433', 'category', '64', '操作url：/111/admin.php?s=/Category/add.html', '1', '1413196266');
INSERT INTO `onethink_action_log` VALUES ('254', '11', '1', '2130706433', 'category', '64', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413198684');
INSERT INTO `onethink_action_log` VALUES ('255', '11', '1', '2130706433', 'category', '62', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413198707');
INSERT INTO `onethink_action_log` VALUES ('256', '11', '1', '2130706433', 'category', '64', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413198737');
INSERT INTO `onethink_action_log` VALUES ('257', '11', '1', '2130706433', 'category', '62', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413198744');
INSERT INTO `onethink_action_log` VALUES ('258', '11', '1', '2130706433', 'category', '53', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413198752');
INSERT INTO `onethink_action_log` VALUES ('259', '11', '1', '2130706433', 'category', '53', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413198759');
INSERT INTO `onethink_action_log` VALUES ('260', '11', '1', '2130706433', 'category', '57', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413198856');
INSERT INTO `onethink_action_log` VALUES ('261', '11', '1', '2130706433', 'category', '52', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413198901');
INSERT INTO `onethink_action_log` VALUES ('262', '1', '1', '2130706433', 'member', '1', '123在2014-10-13 19:32登录了后台', '1', '1413199936');
INSERT INTO `onethink_action_log` VALUES ('263', '11', '1', '2130706433', 'category', '65', '操作url：/111/admin.php?s=/Category/add.html', '1', '1413199966');
INSERT INTO `onethink_action_log` VALUES ('264', '11', '1', '2130706433', 'category', '65', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413199991');
INSERT INTO `onethink_action_log` VALUES ('265', '11', '1', '2130706433', 'category', '65', '操作url：/111/admin.php?s=/Category/remove/id/65.html', '1', '1413200732');
INSERT INTO `onethink_action_log` VALUES ('266', '11', '1', '2130706433', 'category', '66', '操作url：/111/admin.php?s=/Category/add.html', '1', '1413201862');
INSERT INTO `onethink_action_log` VALUES ('267', '9', '1', '2130706433', 'channel', '4', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1413205557');
INSERT INTO `onethink_action_log` VALUES ('268', '9', '1', '2130706433', 'channel', '8', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1413205562');
INSERT INTO `onethink_action_log` VALUES ('269', '9', '1', '2130706433', 'channel', '7', '操作url：/111/admin.php?s=/Channel/edit.html', '1', '1413205567');
INSERT INTO `onethink_action_log` VALUES ('270', '6', '1', '2130706433', 'config', '0', '操作url：/111/admin.php?s=/Config/del/id/39.html', '1', '1413220822');
INSERT INTO `onethink_action_log` VALUES ('271', '6', '1', '2130706433', 'config', '40', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1413221049');
INSERT INTO `onethink_action_log` VALUES ('272', '6', '1', '2130706433', 'config', '40', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1413224479');
INSERT INTO `onethink_action_log` VALUES ('273', '1', '1', '2130706433', 'member', '1', '123在2014-10-14 11:37登录了后台', '1', '1413257837');
INSERT INTO `onethink_action_log` VALUES ('274', '1', '1', '2130706433', 'member', '1', '123在2014-10-14 12:57登录了后台', '1', '1413262655');
INSERT INTO `onethink_action_log` VALUES ('275', '1', '1', '2130706433', 'member', '1', '123在2014-10-14 13:30登录了后台', '1', '1413264601');
INSERT INTO `onethink_action_log` VALUES ('276', '1', '1', '2130706433', 'member', '1', '123在2014-10-14 13:50登录了后台', '1', '1413265855');
INSERT INTO `onethink_action_log` VALUES ('277', '1', '1', '2130706433', 'member', '1', '123在2014-10-14 14:45登录了后台', '1', '1413269157');
INSERT INTO `onethink_action_log` VALUES ('278', '1', '1', '2130706433', 'member', '1', '123在2014-10-14 19:36登录了后台', '1', '1413286568');
INSERT INTO `onethink_action_log` VALUES ('279', '9', '1', '2130706433', 'channel', '0', '操作url：/111/admin.php?s=/Channel/del/id/3.html', '1', '1413288594');
INSERT INTO `onethink_action_log` VALUES ('280', '9', '1', '2130706433', 'channel', '0', '操作url：/111/admin.php?s=/Channel/del/id/4.html', '1', '1413288603');
INSERT INTO `onethink_action_log` VALUES ('281', '11', '1', '2130706433', 'category', '64', '操作url：/111/admin.php?s=/Category/remove/id/64.html', '1', '1413288619');
INSERT INTO `onethink_action_log` VALUES ('282', '11', '1', '2130706433', 'category', '62', '操作url：/111/admin.php?s=/Category/remove/id/62.html', '1', '1413288623');
INSERT INTO `onethink_action_log` VALUES ('283', '11', '1', '2130706433', 'category', '53', '操作url：/111/admin.php?s=/Category/remove/id/53.html', '1', '1413288628');
INSERT INTO `onethink_action_log` VALUES ('284', '11', '1', '2130706433', 'category', '61', '操作url：/111/admin.php?s=/Category/remove/id/61.html', '1', '1413288632');
INSERT INTO `onethink_action_log` VALUES ('285', '11', '1', '2130706433', 'category', '67', '操作url：/111/admin.php?s=/Category/add.html', '1', '1413297876');
INSERT INTO `onethink_action_log` VALUES ('286', '11', '1', '2130706433', 'category', '67', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413297887');
INSERT INTO `onethink_action_log` VALUES ('287', '1', '1', '2130706433', 'member', '1', '123在2014-10-15 00:35登录了后台', '1', '1413304521');
INSERT INTO `onethink_action_log` VALUES ('288', '1', '1', '2130706433', 'member', '1', '123在2014-10-15 00:40登录了后台', '1', '1413304815');
INSERT INTO `onethink_action_log` VALUES ('289', '1', '1', '2130706433', 'member', '1', '123在2014-10-16 04:51登录了后台', '1', '1413406273');
INSERT INTO `onethink_action_log` VALUES ('290', '1', '1', '2130706433', 'member', '1', '123在2014-10-16 15:11登录了后台', '1', '1413443498');
INSERT INTO `onethink_action_log` VALUES ('291', '1', '1', '2130706433', 'member', '1', '123在2014-10-16 18:00登录了后台', '1', '1413453631');
INSERT INTO `onethink_action_log` VALUES ('292', '1', '1', '2130706433', 'member', '1', '123在2014-10-17 14:19登录了后台', '1', '1413526792');
INSERT INTO `onethink_action_log` VALUES ('293', '1', '1', '2130706433', 'member', '1', '123在2014-10-19 21:52登录了后台', '1', '1413726732');
INSERT INTO `onethink_action_log` VALUES ('294', '1', '1', '2130706433', 'member', '1', '123在2014-10-19 22:08登录了后台', '1', '1413727721');
INSERT INTO `onethink_action_log` VALUES ('295', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 03:42登录了后台', '1', '1413747771');
INSERT INTO `onethink_action_log` VALUES ('296', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 05:26登录了后台', '1', '1413753983');
INSERT INTO `onethink_action_log` VALUES ('297', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 06:22登录了后台', '1', '1413757367');
INSERT INTO `onethink_action_log` VALUES ('298', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 06:23登录了后台', '1', '1413757428');
INSERT INTO `onethink_action_log` VALUES ('299', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 06:25登录了后台', '1', '1413757507');
INSERT INTO `onethink_action_log` VALUES ('300', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 06:33登录了后台', '1', '1413757991');
INSERT INTO `onethink_action_log` VALUES ('301', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 06:35登录了后台', '1', '1413758155');
INSERT INTO `onethink_action_log` VALUES ('302', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 06:36登录了后台', '1', '1413758164');
INSERT INTO `onethink_action_log` VALUES ('303', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 06:36登录了后台', '1', '1413758195');
INSERT INTO `onethink_action_log` VALUES ('304', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 06:36登录了后台', '1', '1413758203');
INSERT INTO `onethink_action_log` VALUES ('305', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 06:37登录了后台', '1', '1413758230');
INSERT INTO `onethink_action_log` VALUES ('306', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 06:52登录了后台', '1', '1413759136');
INSERT INTO `onethink_action_log` VALUES ('307', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 06:59登录了后台', '1', '1413759552');
INSERT INTO `onethink_action_log` VALUES ('308', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 07:00登录了后台', '1', '1413759645');
INSERT INTO `onethink_action_log` VALUES ('309', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 07:01登录了后台', '1', '1413759707');
INSERT INTO `onethink_action_log` VALUES ('310', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 07:02登录了后台', '1', '1413759767');
INSERT INTO `onethink_action_log` VALUES ('311', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 07:04登录了后台', '1', '1413759875');
INSERT INTO `onethink_action_log` VALUES ('312', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 07:05登录了后台', '1', '1413759917');
INSERT INTO `onethink_action_log` VALUES ('313', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 10:48登录了后台', '1', '1413773304');
INSERT INTO `onethink_action_log` VALUES ('314', '1', '1', '2130706433', 'member', '1', '123在2014-10-20 21:03登录了后台', '1', '1413810181');
INSERT INTO `onethink_action_log` VALUES ('315', '8', '1', '2130706433', 'attribute', '44', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1413845084');
INSERT INTO `onethink_action_log` VALUES ('316', '7', '1', '2130706433', 'model', '1', '操作url：/111/admin.php?s=/Model/update.html', '1', '1413845425');
INSERT INTO `onethink_action_log` VALUES ('317', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1413845503');
INSERT INTO `onethink_action_log` VALUES ('318', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1413845554');
INSERT INTO `onethink_action_log` VALUES ('319', '11', '1', '2130706433', 'category', '52', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413845667');
INSERT INTO `onethink_action_log` VALUES ('320', '11', '1', '2130706433', 'category', '58', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413845696');
INSERT INTO `onethink_action_log` VALUES ('321', '11', '1', '2130706433', 'category', '67', '操作url：/111/admin.php?s=/Category/remove/id/67.html', '1', '1413845860');
INSERT INTO `onethink_action_log` VALUES ('322', '11', '1', '2130706433', 'category', '40', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413845937');
INSERT INTO `onethink_action_log` VALUES ('323', '11', '1', '2130706433', 'category', '41', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1413845950');
INSERT INTO `onethink_action_log` VALUES ('324', '10', '1', '2130706433', 'Menu', '131', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1413886978');
INSERT INTO `onethink_action_log` VALUES ('325', '10', '1', '2130706433', 'Menu', '131', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1413887696');
INSERT INTO `onethink_action_log` VALUES ('326', '10', '1', '2130706433', 'Menu', '132', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1413887764');
INSERT INTO `onethink_action_log` VALUES ('327', '10', '1', '2130706433', 'Menu', '132', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1413887805');
INSERT INTO `onethink_action_log` VALUES ('328', '10', '1', '2130706433', 'Menu', '133', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1413887862');
INSERT INTO `onethink_action_log` VALUES ('329', '1', '1', '2130706433', 'member', '1', '123在2014-10-21 18:38登录了后台', '1', '1413887917');
INSERT INTO `onethink_action_log` VALUES ('330', '10', '1', '2130706433', 'Menu', '0', '操作url：/111/admin.php?s=/Menu/del/id/124.html', '1', '1413888237');
INSERT INTO `onethink_action_log` VALUES ('331', '10', '1', '2130706433', 'Menu', '0', '操作url：/111/admin.php?s=/Menu/del/id/129.html', '1', '1413888245');
INSERT INTO `onethink_action_log` VALUES ('332', '1', '1', '2130706433', 'member', '1', '123在2014-10-21 18:44登录了后台', '1', '1413888279');
INSERT INTO `onethink_action_log` VALUES ('333', '10', '1', '2130706433', 'Menu', '131', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1413888403');
INSERT INTO `onethink_action_log` VALUES ('334', '10', '1', '2130706433', 'Menu', '2', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1413888418');
INSERT INTO `onethink_action_log` VALUES ('335', '1', '1', '2130706433', 'member', '1', '123在2014-10-21 18:47登录了后台', '1', '1413888439');
INSERT INTO `onethink_action_log` VALUES ('336', '1', '1', '2130706433', 'member', '1', '123在2014-10-22 00:28登录了后台', '1', '1413908883');
INSERT INTO `onethink_action_log` VALUES ('337', '1', '1', '2130706433', 'member', '1', '123在2014-10-22 02:46登录了后台', '1', '1413917212');
INSERT INTO `onethink_action_log` VALUES ('338', '1', '1', '2130706433', 'member', '1', '123在2014-10-22 04:35登录了后台', '1', '1413923707');
INSERT INTO `onethink_action_log` VALUES ('339', '1', '1', '2130706433', 'member', '1', '123在2014-10-22 06:53登录了后台', '1', '1413932026');
INSERT INTO `onethink_action_log` VALUES ('340', '1', '1', '2130706433', 'member', '1', '123在2014-10-22 06:56登录了后台', '1', '1413932169');
INSERT INTO `onethink_action_log` VALUES ('341', '1', '1', '2130706433', 'member', '1', '123在2014-10-22 07:13登录了后台', '1', '1413933236');
INSERT INTO `onethink_action_log` VALUES ('342', '1', '1', '2130706433', 'member', '1', '123在2014-10-22 07:17登录了后台', '1', '1413933471');
INSERT INTO `onethink_action_log` VALUES ('343', '1', '1', '2130706433', 'member', '1', '123在2014-10-22 07:20登录了后台', '1', '1413933605');
INSERT INTO `onethink_action_log` VALUES ('344', '1', '1', '2130706433', 'member', '1', '123在2014-10-22 18:32登录了后台', '1', '1413973971');
INSERT INTO `onethink_action_log` VALUES ('345', '11', '1', '2130706433', 'category', '68', '操作url：/111/admin.php?s=/Category/add.html', '1', '1413987264');
INSERT INTO `onethink_action_log` VALUES ('346', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 02:08登录了后台', '1', '1414001321');
INSERT INTO `onethink_action_log` VALUES ('347', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 02:10登录了后台', '1', '1414001450');
INSERT INTO `onethink_action_log` VALUES ('348', '6', '1', '2130706433', 'config', '41', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1414001482');
INSERT INTO `onethink_action_log` VALUES ('349', '6', '1', '2130706433', 'config', '42', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1414001495');
INSERT INTO `onethink_action_log` VALUES ('350', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 02:17登录了后台', '1', '1414001858');
INSERT INTO `onethink_action_log` VALUES ('351', '7', '1', '2130706433', 'model', '7', '操作url：/111/admin.php?s=/Model/update.html', '1', '1414002884');
INSERT INTO `onethink_action_log` VALUES ('352', '7', '1', '2130706433', 'model', '7', '操作url：/111/admin.php?s=/Model/update.html', '1', '1414003180');
INSERT INTO `onethink_action_log` VALUES ('353', '7', '1', '2130706433', 'model', '7', '操作url：/111/admin.php?s=/Model/update.html', '1', '1414003271');
INSERT INTO `onethink_action_log` VALUES ('354', '11', '1', '2130706433', 'category', '56', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1414003373');
INSERT INTO `onethink_action_log` VALUES ('355', '11', '1', '2130706433', 'category', '56', '操作url：/111/admin.php?s=/Category/edit.html', '1', '1414003441');
INSERT INTO `onethink_action_log` VALUES ('356', '10', '1', '2130706433', 'Menu', '134', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414003785');
INSERT INTO `onethink_action_log` VALUES ('357', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 02:50登录了后台', '1', '1414003810');
INSERT INTO `onethink_action_log` VALUES ('358', '10', '1', '2130706433', 'Menu', '134', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414011834');
INSERT INTO `onethink_action_log` VALUES ('359', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 05:05登录了后台', '1', '1414011931');
INSERT INTO `onethink_action_log` VALUES ('360', '11', '1', '2130706433', 'category', '69', '操作url：/111/admin.php?s=/Fcoupon/add.html', '1', '1414012294');
INSERT INTO `onethink_action_log` VALUES ('361', '11', '1', '2130706433', 'category', '1', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414012468');
INSERT INTO `onethink_action_log` VALUES ('362', '11', '1', '2130706433', 'category', '2', '操作url：/111/admin.php?s=/Fcoupon/add.html', '1', '1414012758');
INSERT INTO `onethink_action_log` VALUES ('363', '11', '1', '2130706433', 'category', '3', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414012817');
INSERT INTO `onethink_action_log` VALUES ('364', '11', '1', '2130706433', 'category', '4', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414012977');
INSERT INTO `onethink_action_log` VALUES ('365', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 05:41登录了后台', '1', '1414014099');
INSERT INTO `onethink_action_log` VALUES ('366', '11', '1', '2130706433', 'category', '1', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414014346');
INSERT INTO `onethink_action_log` VALUES ('367', '10', '1', '2130706433', 'Menu', '134', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414014960');
INSERT INTO `onethink_action_log` VALUES ('368', '11', '1', '2130706433', 'category', '2', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414015191');
INSERT INTO `onethink_action_log` VALUES ('369', '11', '1', '2130706433', 'category', '3', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414015207');
INSERT INTO `onethink_action_log` VALUES ('370', '11', '1', '2130706433', 'category', '4', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414015220');
INSERT INTO `onethink_action_log` VALUES ('371', '11', '1', '2130706433', 'category', '1', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414015302');
INSERT INTO `onethink_action_log` VALUES ('372', '10', '1', '2130706433', 'Menu', '135', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414015522');
INSERT INTO `onethink_action_log` VALUES ('373', '10', '1', '2130706433', 'Menu', '136', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414015584');
INSERT INTO `onethink_action_log` VALUES ('374', '10', '1', '2130706433', 'Menu', '137', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414015692');
INSERT INTO `onethink_action_log` VALUES ('375', '10', '1', '2130706433', 'Menu', '137', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414015704');
INSERT INTO `onethink_action_log` VALUES ('376', '10', '1', '2130706433', 'Menu', '138', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414015805');
INSERT INTO `onethink_action_log` VALUES ('377', '10', '1', '2130706433', 'Menu', '138', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414015816');
INSERT INTO `onethink_action_log` VALUES ('378', '10', '1', '2130706433', 'Menu', '139', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414015871');
INSERT INTO `onethink_action_log` VALUES ('379', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 06:11登录了后台', '1', '1414015911');
INSERT INTO `onethink_action_log` VALUES ('380', '10', '1', '2130706433', 'Menu', '132', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414016053');
INSERT INTO `onethink_action_log` VALUES ('381', '10', '1', '2130706433', 'Menu', '133', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414016063');
INSERT INTO `onethink_action_log` VALUES ('382', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 06:15登录了后台', '1', '1414016104');
INSERT INTO `onethink_action_log` VALUES ('383', '10', '1', '2130706433', 'Menu', '0', '操作url：/111/admin.php?s=/Menu/del/id/136.html', '1', '1414045636');
INSERT INTO `onethink_action_log` VALUES ('384', '10', '1', '2130706433', 'Menu', '133', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414045653');
INSERT INTO `onethink_action_log` VALUES ('385', '10', '1', '2130706433', 'Menu', '135', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414045708');
INSERT INTO `onethink_action_log` VALUES ('386', '10', '1', '2130706433', 'Menu', '137', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414045745');
INSERT INTO `onethink_action_log` VALUES ('387', '10', '1', '2130706433', 'Menu', '138', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414045757');
INSERT INTO `onethink_action_log` VALUES ('388', '10', '1', '2130706433', 'Menu', '139', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414045770');
INSERT INTO `onethink_action_log` VALUES ('389', '10', '1', '2130706433', 'Menu', '132', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414045788');
INSERT INTO `onethink_action_log` VALUES ('390', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 14:30登录了后台', '1', '1414045820');
INSERT INTO `onethink_action_log` VALUES ('391', '10', '1', '2130706433', 'Menu', '138', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414046663');
INSERT INTO `onethink_action_log` VALUES ('392', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 14:44登录了后台', '1', '1414046684');
INSERT INTO `onethink_action_log` VALUES ('393', '10', '1', '2130706433', 'Menu', '133', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414048314');
INSERT INTO `onethink_action_log` VALUES ('394', '10', '1', '2130706433', 'Menu', '135', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414048334');
INSERT INTO `onethink_action_log` VALUES ('395', '10', '1', '2130706433', 'Menu', '138', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414048372');
INSERT INTO `onethink_action_log` VALUES ('396', '10', '1', '2130706433', 'Menu', '139', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414048387');
INSERT INTO `onethink_action_log` VALUES ('397', '10', '1', '2130706433', 'Menu', '131', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414048404');
INSERT INTO `onethink_action_log` VALUES ('398', '10', '1', '2130706433', 'Menu', '133', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414048542');
INSERT INTO `onethink_action_log` VALUES ('399', '10', '1', '2130706433', 'Menu', '135', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414048719');
INSERT INTO `onethink_action_log` VALUES ('400', '10', '1', '2130706433', 'Menu', '138', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414048735');
INSERT INTO `onethink_action_log` VALUES ('401', '10', '1', '2130706433', 'Menu', '139', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414048747');
INSERT INTO `onethink_action_log` VALUES ('402', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 15:19登录了后台', '1', '1414048775');
INSERT INTO `onethink_action_log` VALUES ('403', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 15:24登录了后台', '1', '1414049059');
INSERT INTO `onethink_action_log` VALUES ('404', '10', '1', '2130706433', 'Menu', '139', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414050666');
INSERT INTO `onethink_action_log` VALUES ('405', '10', '1', '2130706433', 'Menu', '138', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414050675');
INSERT INTO `onethink_action_log` VALUES ('406', '10', '1', '2130706433', 'Menu', '135', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414050694');
INSERT INTO `onethink_action_log` VALUES ('407', '10', '1', '2130706433', 'Menu', '134', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414050706');
INSERT INTO `onethink_action_log` VALUES ('408', '10', '1', '2130706433', 'Menu', '133', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414050718');
INSERT INTO `onethink_action_log` VALUES ('409', '10', '1', '2130706433', 'Menu', '135', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414050727');
INSERT INTO `onethink_action_log` VALUES ('410', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 15:52登录了后台', '1', '1414050763');
INSERT INTO `onethink_action_log` VALUES ('411', '10', '1', '2130706433', 'Menu', '140', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414051715');
INSERT INTO `onethink_action_log` VALUES ('412', '10', '1', '2130706433', 'Menu', '140', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414051732');
INSERT INTO `onethink_action_log` VALUES ('413', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 16:10登录了后台', '1', '1414051812');
INSERT INTO `onethink_action_log` VALUES ('414', '10', '1', '2130706433', 'Menu', '138', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414054906');
INSERT INTO `onethink_action_log` VALUES ('415', '10', '1', '2130706433', 'Menu', '139', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414054925');
INSERT INTO `onethink_action_log` VALUES ('416', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 17:03登录了后台', '1', '1414055007');
INSERT INTO `onethink_action_log` VALUES ('417', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 18:11登录了后台', '1', '1414059090');
INSERT INTO `onethink_action_log` VALUES ('418', '10', '1', '2130706433', 'Menu', '140', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414074147');
INSERT INTO `onethink_action_log` VALUES ('419', '10', '1', '2130706433', 'Menu', '140', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414074473');
INSERT INTO `onethink_action_log` VALUES ('420', '10', '1', '2130706433', 'Menu', '139', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414074488');
INSERT INTO `onethink_action_log` VALUES ('421', '10', '1', '2130706433', 'Menu', '138', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414074507');
INSERT INTO `onethink_action_log` VALUES ('422', '10', '1', '2130706433', 'Menu', '137', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414074524');
INSERT INTO `onethink_action_log` VALUES ('423', '10', '1', '2130706433', 'Menu', '141', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414074604');
INSERT INTO `onethink_action_log` VALUES ('424', '10', '1', '2130706433', 'Menu', '142', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414074647');
INSERT INTO `onethink_action_log` VALUES ('425', '10', '1', '2130706433', 'Menu', '142', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414074666');
INSERT INTO `onethink_action_log` VALUES ('426', '10', '1', '2130706433', 'Menu', '140', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414074690');
INSERT INTO `onethink_action_log` VALUES ('427', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 22:32登录了后台', '1', '1414074736');
INSERT INTO `onethink_action_log` VALUES ('428', '1', '1', '2130706433', 'member', '1', '123在2014-10-23 23:09登录了后台', '1', '1414076997');
INSERT INTO `onethink_action_log` VALUES ('429', '10', '1', '2130706433', 'Menu', '143', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414081937');
INSERT INTO `onethink_action_log` VALUES ('430', '10', '1', '2130706433', 'Menu', '143', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414081954');
INSERT INTO `onethink_action_log` VALUES ('431', '10', '1', '2130706433', 'Menu', '144', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414082021');
INSERT INTO `onethink_action_log` VALUES ('432', '10', '1', '2130706433', 'Menu', '143', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414082036');
INSERT INTO `onethink_action_log` VALUES ('433', '10', '1', '2130706433', 'Menu', '144', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414082094');
INSERT INTO `onethink_action_log` VALUES ('434', '10', '1', '2130706433', 'Menu', '143', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414082103');
INSERT INTO `onethink_action_log` VALUES ('435', '10', '1', '2130706433', 'Menu', '141', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414082117');
INSERT INTO `onethink_action_log` VALUES ('436', '10', '1', '2130706433', 'Menu', '142', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414082128');
INSERT INTO `onethink_action_log` VALUES ('437', '10', '1', '2130706433', 'Menu', '145', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414082175');
INSERT INTO `onethink_action_log` VALUES ('438', '1', '1', '2130706433', 'member', '1', '123在2014-10-24 00:37登录了后台', '1', '1414082242');
INSERT INTO `onethink_action_log` VALUES ('439', '1', '1', '2130706433', 'member', '1', '123在2014-10-24 02:04登录了后台', '1', '1414087461');
INSERT INTO `onethink_action_log` VALUES ('440', '1', '1', '2130706433', 'member', '1', '123在2014-10-24 04:33登录了后台', '1', '1414096412');
INSERT INTO `onethink_action_log` VALUES ('441', '10', '1', '2130706433', 'Menu', '146', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414099072');
INSERT INTO `onethink_action_log` VALUES ('442', '10', '1', '2130706433', 'Menu', '143', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414099090');
INSERT INTO `onethink_action_log` VALUES ('443', '10', '1', '2130706433', 'Menu', '144', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414099104');
INSERT INTO `onethink_action_log` VALUES ('444', '10', '1', '2130706433', 'Menu', '145', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414099114');
INSERT INTO `onethink_action_log` VALUES ('445', '10', '1', '2130706433', 'Menu', '16', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414099135');
INSERT INTO `onethink_action_log` VALUES ('446', '1', '1', '2130706433', 'member', '1', '123在2014-10-24 05:19登录了后台', '1', '1414099155');
INSERT INTO `onethink_action_log` VALUES ('447', '10', '1', '2130706433', 'Menu', '147', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414133835');
INSERT INTO `onethink_action_log` VALUES ('448', '10', '1', '2130706433', 'Menu', '148', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414133897');
INSERT INTO `onethink_action_log` VALUES ('449', '10', '1', '2130706433', 'Menu', '147', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414133926');
INSERT INTO `onethink_action_log` VALUES ('450', '10', '1', '2130706433', 'Menu', '148', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414133941');
INSERT INTO `onethink_action_log` VALUES ('451', '10', '1', '2130706433', 'Menu', '149', '操作url：/111/admin.php?s=/Menu/add.html', '1', '1414133997');
INSERT INTO `onethink_action_log` VALUES ('452', '10', '1', '2130706433', 'Menu', '148', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414134017');
INSERT INTO `onethink_action_log` VALUES ('453', '1', '1', '2130706433', 'member', '1', '123在2014-10-24 15:02登录了后台', '1', '1414134162');
INSERT INTO `onethink_action_log` VALUES ('454', '10', '1', '2130706433', 'Menu', '149', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414135864');
INSERT INTO `onethink_action_log` VALUES ('455', '10', '1', '2130706433', 'Menu', '148', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414135875');
INSERT INTO `onethink_action_log` VALUES ('456', '10', '1', '2130706433', 'Menu', '147', '操作url：/111/admin.php?s=/Menu/edit.html', '1', '1414135887');
INSERT INTO `onethink_action_log` VALUES ('457', '10', '1', '2130706433', 'Menu', '0', '操作url：/111/admin.php?s=/Report/del.html', '1', '1414137371');
INSERT INTO `onethink_action_log` VALUES ('458', '1', '1', '2130706433', 'member', '1', '123在2014-10-24 17:05登录了后台', '1', '1414141551');
INSERT INTO `onethink_action_log` VALUES ('459', '1', '1', '2130706433', 'member', '1', '123在2014-10-24 18:34登录了后台', '1', '1414146898');
INSERT INTO `onethink_action_log` VALUES ('460', '6', '1', '2130706433', 'config', '44', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1414164642');
INSERT INTO `onethink_action_log` VALUES ('461', '6', '1', '2130706433', 'config', '45', '操作url：/111/admin.php?s=/Config/edit.html', '1', '1414164654');
INSERT INTO `onethink_action_log` VALUES ('462', '11', '1', '2130706433', 'category', '5', '操作url：/111/admin.php?s=/Fcoupon/add.html', '1', '1414174826');
INSERT INTO `onethink_action_log` VALUES ('463', '11', '1', '2130706433', 'category', '1', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414174845');
INSERT INTO `onethink_action_log` VALUES ('464', '11', '1', '2130706433', 'category', '4', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414174856');
INSERT INTO `onethink_action_log` VALUES ('465', '11', '1', '2130706433', 'category', '2', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414174944');
INSERT INTO `onethink_action_log` VALUES ('466', '11', '1', '2130706433', 'category', '3', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414175059');
INSERT INTO `onethink_action_log` VALUES ('467', '11', '1', '2130706433', 'category', '3', '操作url：/111/admin.php?s=/Fcoupon/edit.html', '1', '1414175369');
INSERT INTO `onethink_action_log` VALUES ('468', '8', '1', '2130706433', 'attribute', '46', '操作url：/111/admin.php?s=/Attribute/update.html', '1', '1414177236');
INSERT INTO `onethink_action_log` VALUES ('469', '7', '1', '2130706433', 'model', '5', '操作url：/111/admin.php?s=/Model/update.html', '1', '1414177267');
INSERT INTO `onethink_action_log` VALUES ('470', '1', '1', '2130706433', 'member', '1', '123在2014-10-25 17:22登录了后台', '1', '1414228940');
INSERT INTO `onethink_action_log` VALUES ('471', '1', '1', '2130706433', 'member', '1', '123在2014-10-25 18:34登录了后台', '1', '1414233241');

-- -----------------------------
-- Table structure for `onethink_addons`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_addons`;
CREATE TABLE `onethink_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `onethink_addons`
-- -----------------------------
INSERT INTO `onethink_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0');
INSERT INTO `onethink_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `onethink_addons` VALUES ('3', 'DevTeam', '开发团队信息', '开发团队成员信息', '0', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512022', '0');
INSERT INTO `onethink_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `onethink_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `onethink_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `onethink_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"\",\"comment_short_name_duoshuo\":\"\",\"comment_data_list_duoshuo\":\"\"}', 'thinkphp', '0.1', '1380273962', '0');
INSERT INTO `onethink_addons` VALUES ('16', 'OTcaiji', 'OT采集', 'OT采集插件', '1', '{\"codelogin\":1,\"KEYWORDS\":\"\",\"URL\":\"\",\"LIST\":\"\",\"TITLE\":\"\",\"CONTENT\":\"\"}', 'Marvin(柳英伟)', '0.2', '1411634246', '1');
INSERT INTO `onethink_addons` VALUES ('17', 'ReturnTop', '返回顶部', '回到顶部美化，随机或指定显示，100款样式，每天一种换，天天都用新样式', '0', '{\"random\":\"0\",\"current\":\"79\"}', 'thinkphp', '0.1', '1411634594', '0');
INSERT INTO `onethink_addons` VALUES ('22', 'AliPlay', '支付宝', '支付宝插件,后台配置支持变量。如：价格：$GOODS[\"price\"].但是配置的变量要和数据库商品信息一致。', '1', '{\"pay_type\":\"1\",\"codelogin\":\"1\",\"PARTNER\":\"5456464\",\"KEY\":\"546\",\"SELLER_EMAIL\":\"54645464\",\"NOTIFY_URL\":\"\",\"RETURN_URL\":\"\",\"out_trade_no\":\"132564546564\",\"subject\":\"132564546564\",\"price\":\"{$goodprice}\",\"logistics_fee\":\"10\",\"logistics_type\":\"EXPRESS\",\"logistics_payment\":\"SELLER_PAY\",\"body\":\"\",\"show_url\":\"132564546564\",\"receive_name\":\"\",\"receive_address\":\"\",\"receive_zip\":\"\",\"receive_mobile\":\"13312341234\",\"receive_phone\":\"13312341234\"}', 'Marvin(柳英伟)', '2.0', '1412762558', '0');
INSERT INTO `onethink_addons` VALUES ('19', 'Iyo9Table', '点击成可编辑插件', '向着要编辑的位置点击一下，访位置会变成一个可编辑的input标签，编辑好后，鼠标再点击空白地方，即可保存', '1', 'null', 'i友街', '0.1', '1411636824', '0');
INSERT INTO `onethink_addons` VALUES ('21', 'Template', '模版管理', '模版在线编辑插件', '1', 'null', 'Marvin(柳英伟)', '1.0', '1411637366', '1');
INSERT INTO `onethink_addons` VALUES ('23', 'SyncLogin', '第三方账号同步登陆', '第三方账号同步登陆', '1', '{\"type\":[\"Qq\",\"Sina\"],\"meta\":\"\",\"QqKEY\":\"\",\"QqSecret\":\"\",\"SinaKEY\":\"\",\"SinaSecret\":\"\"}', 'yidian', '0.1', '1412762818', '0');

-- -----------------------------
-- Table structure for `onethink_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attachment`;
CREATE TABLE `onethink_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `onethink_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attribute`;
CREATE TABLE `onethink_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `onethink_attribute`
-- -----------------------------
INSERT INTO `onethink_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录
2:主题
3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '[DOCUMENT_POSITION]', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见
1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除
0:禁用
1:正常
2:待审核
3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html
1:ubb
2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html
1:ubb
2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('36', 'content', '内容详细描述', 'text NOT NULL', 'editor', '', '', '1', '', '5', '0', '1', '1411376156', '1411376156', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('35', 'price', '价格', 'varchar(255) NOT NULL', 'string', '1.00', '', '1', '', '5', '0', '1', '1411430769', '1411375944', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('37', 'weight', '净重', 'varchar(255) NOT NULL', 'string', '500', 'g', '1', '', '5', '0', '1', '1411927788', '1411379961', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('38', 'totalsales', '总销量', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '1', '', '5', '0', '1', '1411380076', '1411380076', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('39', 'area', '产地', 'varchar(255) NOT NULL', 'string', '中国大陆', '', '1', '', '5', '0', '1', '1411380147', '1411380147', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('40', 'ads_pic_id', '首页幻灯大图', 'int(10) UNSIGNED NOT NULL', 'picture', '', '首页幻灯大图', '1', '', '5', '0', '1', '1411815168', '1411815168', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('41', 'adtitle', '广告宣传标题', 'varchar(255) NOT NULL', 'string', '', '副标题', '1', '', '5', '0', '1', '1411815491', '1411815491', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('42', 'yprice', '原价', 'varchar(255) NOT NULL', 'string', '', '产品原价', '1', '', '5', '0', '1', '1411919829', '1411919829', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('43', 'mark', '附加标签', 'varchar(255) NOT NULL', 'string', '', '1-最新上架，2-限时抢购，3-热卖商品，4-限时折扣', '1', '', '5', '0', '1', '1412016261', '1412016196', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('44', 'unionid', '关联商品', 'varchar(255) NOT NULL', 'string', '', '关联商品id,如3,9,10，逗号隔开', '1', '', '5', '0', '1', '1413845084', '1413845084', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('45', 'price', '优惠券价值', '优惠券价值', '', '', '', '1', '', '7', '0', '1', '1414003061', '1414003061', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('46', 'num', '库存', 'int(10) UNSIGNED NOT NULL', 'num', '1', '商品库存数量', '1', '', '5', '0', '1', '1414177236', '1414177236', '', '3', '', 'regex', '', '3', 'function');

-- -----------------------------
-- Table structure for `onethink_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_extend`;
CREATE TABLE `onethink_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `onethink_auth_extend`
-- -----------------------------
INSERT INTO `onethink_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `onethink_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_group`;
CREATE TABLE `onethink_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_group`
-- -----------------------------
INSERT INTO `onethink_auth_group` VALUES ('1', 'admin', '1', '默认用户组', '', '1', '1,2,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,96,97,100,102,103,105,106');
INSERT INTO `onethink_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');

-- -----------------------------
-- Table structure for `onethink_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_group_access`;
CREATE TABLE `onethink_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `onethink_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_rule`;
CREATE TABLE `onethink_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=236 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_rule`
-- -----------------------------
INSERT INTO `onethink_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('17', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('111', 'admin', '2', 'Admin/Article/index', '内容', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('217', 'admin', '1', 'Admin/think/lists', '数据列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('218', 'admin', '1', 'Admin/Order/index', '已提交订单', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('219', 'admin', '1', 'Admin/Ordertransport/index', '已发货订单', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('220', 'admin', '2', 'Admin/Order/index', '订单', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('221', 'admin', '1', 'Admin/Ordercomplete/index', '已签收订单', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('222', 'admin', '1', 'Admin/Fcoupon/index', '优惠券', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('223', 'admin', '2', 'Admin/Statistics/index', '数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('224', 'admin', '1', 'Admin/Back/index', '正退货订单', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('225', 'admin', '1', 'Admin/Backagree/index', '同意退货订单', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('226', 'admin', '1', 'Admin/Backover/index', '已退货订单', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('227', 'admin', '1', 'Admin/Change/index', '正换货商品', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('228', 'admin', '1', 'Admin/Changeagree/index', '同意换货商品', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('229', 'admin', '1', 'Admin/Changeover/index', '已换货商品', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('230', 'admin', '1', 'Admin/Statistics/index', '今日销量统计', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('231', 'admin', '1', 'Admin/Statistics/week', '本周销量统计', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('232', 'admin', '1', 'Admin/Statistics/month', '本月销量统计', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('233', 'admin', '1', 'Admin/Report/index', '每日数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('234', 'admin', '1', 'Admin/Report/week', '每周数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('235', 'admin', '1', 'Admin/Report/month', '每月统计', '1', '');

-- -----------------------------
-- Table structure for `onethink_backlist`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_backlist`;
CREATE TABLE `onethink_backlist` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `goodid` int(225) DEFAULT NULL,
  `num` int(50) DEFAULT NULL,
  `orderid` varchar(225) DEFAULT NULL COMMENT '订单号',
  `tool` varchar(225) DEFAULT NULL COMMENT '订单号',
  `toolid` varchar(225) DEFAULT NULL COMMENT '订单号',
  `uid` int(225) DEFAULT NULL,
  `status` int(10) DEFAULT '1',
  `time` int(10) DEFAULT NULL,
  `info` varchar(225) NOT NULL,
  `total` decimal(50,2) DEFAULT NULL,
  `backinfo` varchar(225) DEFAULT NULL,
  `addressid` int(225) DEFAULT NULL,
  `update_time` int(10) DEFAULT NULL,
  `assistant` int(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_backlist`
-- -----------------------------
INSERT INTO `onethink_backlist` VALUES ('1', '5', '2', '56+', '5+4+', '45+4', '1', '4', '5', '同意退货,已重新提交订单并发货', '80.00', '', '21', '', '');
INSERT INTO `onethink_backlist` VALUES ('4', '8', '4654', '', '', '', '', '3', '', '同意', '0.00', '退货已完成', '21', '1414070662', '');
INSERT INTO `onethink_backlist` VALUES ('5', '8', '2', '', '', '', '123', '1', '1414087501', '暂无', '10.00', '同意退货', '21', '1414071941', '');
INSERT INTO `onethink_backlist` VALUES ('6', '9', '2', '', '', '', '1', '1', '1414067582', '暂无', '0.00', '正在编辑', '22', '1414092363', '');

-- -----------------------------
-- Table structure for `onethink_category`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_category`;
CREATE TABLE `onethink_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '列表绑定模型',
  `model_sub` varchar(100) NOT NULL DEFAULT '' COMMENT '子文档绑定模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  `ismenu` int(11) DEFAULT NULL COMMENT '无限极分类调用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `onethink_category`
-- -----------------------------
INSERT INTO `onethink_category` VALUES ('52', 'fruit', '新鲜水果', '0', '0', '10', '', '', '', '', '', '', '', '5', '5', '2,1,3', '0', '1', '1', '0', '0', '', '', '1411925214', '1413845667', '1', '0', '1');
INSERT INTO `onethink_category` VALUES ('40', 'vegetable', '新鲜蔬菜', '0', '2', '10', '', '', '', '', '', '', '', '5', '5', '2,1,3', '0', '1', '1', '0', '0', '', '', '1411331932', '1413845937', '1', '6', '1');
INSERT INTO `onethink_category` VALUES ('41', 'root vegetables ', '根菜类', '40', '3', '10', '', '', '', '', '', '', '', '5', '5', '2', '0', '1', '1', '0', '0', '', '', '1411332731', '1413845950', '1', '0', '1');
INSERT INTO `onethink_category` VALUES ('42', 'leaf vegetables', '叶菜类', '40', '4', '10', '', '', '', '', '', '', '', '2,3,5', '', '2', '0', '1', '1', '0', '0', '', '', '1411332913', '1412523532', '1', '0', '1');
INSERT INTO `onethink_category` VALUES ('43', 'stem vegetable', '茎菜类', '40', '5', '10', '', '', '', '', '', '', '', '2,3,5', '', '2', '0', '1', '1', '0', '0', '', '', '1411332994', '1412523540', '1', '0', '1');
INSERT INTO `onethink_category` VALUES ('44', 'flower vegetable', '花菜类', '40', '6', '10', '', '', '', '', '', '', '', '2,3,5', '', '2', '0', '1', '1', '0', '0', '', '', '1411333039', '1412523548', '1', '0', '1');
INSERT INTO `onethink_category` VALUES ('45', ' fruit-vegetable', '果菜类', '40', '7', '10', '', '', '', '', '', '', '', '2,3,5', '', '2', '0', '1', '1', '0', '0', '', '', '1411333095', '1412523556', '1', '0', '1');
INSERT INTO `onethink_category` VALUES ('58', 'j_fruit', '进口水果', '52', '0', '10', '', '', '', '', '', '', '', '5', '5', '2,1,3', '0', '1', '1', '0', '0', '', '', '1411935041', '1413845696', '1', '0', '1');
INSERT INTO `onethink_category` VALUES ('56', 'notice', '公告', '0', '8', '10', '', '', '', '', '', '', '', '2', '5', '2', '0', '1', '1', '0', '1', '', '', '1411929200', '1414003441', '1', '0', '0');
INSERT INTO `onethink_category` VALUES ('57', 'c_fruit', '国内水果', '52', '0', '10', '', '', '', '', '', '', '', '2,3,5', '5', '2', '0', '1', '1', '0', '0', '', '', '1411934874', '1413198856', '1', '0', '1');
INSERT INTO `onethink_category` VALUES ('68', 'coupon', '优惠券', '0', '0', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1413987264', '1413987264', '1', '0', '');

-- -----------------------------
-- Table structure for `onethink_change`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_change`;
CREATE TABLE `onethink_change` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `goodid` int(225) DEFAULT NULL,
  `num` int(50) DEFAULT NULL,
  `orderid` varchar(225) DEFAULT NULL COMMENT '订单号',
  `tool` varchar(225) DEFAULT NULL COMMENT '订单号',
  `toolid` varchar(225) DEFAULT NULL COMMENT '订单号',
  `uid` int(225) DEFAULT NULL,
  `status` int(10) DEFAULT '1',
  `time` int(10) DEFAULT NULL,
  `info` varchar(225) NOT NULL,
  `total` decimal(50,2) DEFAULT NULL,
  `backinfo` varchar(225) DEFAULT NULL,
  `addressid` int(225) DEFAULT NULL,
  `update_time` int(10) DEFAULT NULL,
  `assistant` int(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_change`
-- -----------------------------
INSERT INTO `onethink_change` VALUES ('7', '5', '6', '455', '564', '1', '', '1', '1414087501', '5656', '', '正处理换货商品', '', '1414076414', '1');

-- -----------------------------
-- Table structure for `onethink_channel`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_channel`;
CREATE TABLE `onethink_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_channel`
-- -----------------------------
INSERT INTO `onethink_channel` VALUES ('1', '0', '首页', 'Index/index', '1', '1379475111', '1412579864', '1', '0');
INSERT INTO `onethink_channel` VALUES ('7', '0', '新鲜水果', 'Article/index?category=fruit', '5', '1412760390', '1413205567', '1', '0');
INSERT INTO `onethink_channel` VALUES ('5', '4', '根菜类', 'Article/index?category=root vegetables', '0', '1411719441', '1411719441', '1', '0');
INSERT INTO `onethink_channel` VALUES ('8', '0', '个人中心', 'Center/index', '4', '1412872458', '1413205562', '1', '0');

-- -----------------------------
-- Table structure for `onethink_check_info`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_check_info`;
CREATE TABLE `onethink_check_info` (
  `uid` int(11) DEFAULT NULL,
  `con_num` int(11) DEFAULT '1',
  `total_num` int(11) DEFAULT '1',
  `ctime` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `onethink_config`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_config`;
CREATE TABLE `onethink_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_config`
-- -----------------------------
INSERT INTO `onethink_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台*显示标题*', '1378898976', '1412577255', '1', 'b2b商城系统-onethink b2b商城系统-，thinkphp商城系统', '0');
INSERT INTO `onethink_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', 'b2b商城系统-onethink b2b商城系统-，thinkphp商城系统', '1');
INSERT INTO `onethink_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', 'ThinkPHP,OneThink，b2b商城系统', '8');
INSERT INTO `onethink_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `onethink_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字
1:字符
2:文本
3:数组
4:枚举', '2');
INSERT INTO `onethink_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '沪ICP备12007941号-2', '9');
INSERT INTO `onethink_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表推荐
2:频道推荐
4:首页推荐', '3');
INSERT INTO `onethink_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见
1:仅注册会员可见
2:仅管理员可见', '4');
INSERT INTO `onethink_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认
blue_color:紫罗兰
amaze:妹子UI', '后台颜色风格', '1379122533', '1411636415', '1', 'default_color', '10');
INSERT INTO `onethink_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本
2:内容
3:用户
4:系统
5:运费', '4');
INSERT INTO `onethink_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图
2:控制器', '6');
INSERT INTO `onethink_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1
AUTH_TYPE:2', '8');
INSERT INTO `onethink_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能
1:开启草稿功能
', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `onethink_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `onethink_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '10');
INSERT INTO `onethink_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册
1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `onethink_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day
3024-night:3024 night
ambiance:ambiance
base16-dark:base16 dark
base16-light:base16 light
blackboard:blackboard
cobalt:cobalt
eclipse:eclipse
elegant:elegant
erlang-dark:erlang-dark
lesser-dark:lesser-dark
midnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `onethink_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `onethink_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `onethink_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩
1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `onethink_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通
4:一般
9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `onethink_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭
1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `onethink_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox
1:article/mydocument
2:Category/tree
3:Index/verify
4:file/upload
5:file/download
6:user/updatePassword
7:user/updateNickname
8:user/submitPassword
9:user/submitNickname
10:file/uploadpicture', '0');
INSERT INTO `onethink_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook
1:Addons/edithook
2:Addons/delhook
3:Addons/updateHook
4:Admin/getMenus
5:Admin/recordList
6:AuthManager/updateRules
7:AuthManager/tree', '0');
INSERT INTO `onethink_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '0');
INSERT INTO `onethink_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `onethink_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭
1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');
INSERT INTO `onethink_config` VALUES ('40', 'HOTSEARCH', '1', '热词', '1', '', '热门搜索词', '1413221018', '1413224479', '1', '国庆节放假时间,商务小清新,苹果,中国风,美女', '0');
INSERT INTO `onethink_config` VALUES ('41', 'SHIPPRICE', '0', '运费', '5', '', '低于一定金额的运费', '1414001070', '1414001482', '1', '10', '0');
INSERT INTO `onethink_config` VALUES ('42', 'LOWWEST', '0', '最低消费金额', '5', '', '用户最低消费的金额，低于该金额，则增加运费', '1414001165', '1414001495', '1', '50', '0');
INSERT INTO `onethink_config` VALUES ('43', 'RATIO', '0', '积分现金兑换比', '5', '', '1000表示1000积分可兑换成1元', '1414153401', '1414153401', '1', '1000', '0');
INSERT INTO `onethink_config` VALUES ('44', 'DEADTIME', '0', '退货有效期', '5', '', '从订单签收完成多少天内可以退货', '1414164561', '1414164642', '1', '7', '0');
INSERT INTO `onethink_config` VALUES ('45', 'CHANGETIME', '0', '换货期', '5', '', '订单签收多少天内后可以换货', '1414164627', '1414164654', '1', '15', '0');
INSERT INTO `onethink_config` VALUES ('46', 'QQ', '1', 'QQ客服', '5', '', '网站客服的qq代码', '1414183635', '1414183635', '1', '1010422715', '0');
INSERT INTO `onethink_config` VALUES ('47', 'ALWW', '0', '阿里旺旺号', '5', '', '网站阿里旺旺客服', '1414183716', '1414183716', '1', '', '0');

-- -----------------------------
-- Table structure for `onethink_document`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document`;
CREATE TABLE `onethink_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `onethink_document`
-- -----------------------------
INSERT INTO `onethink_document` VALUES ('12', '1', '', '肯德基电子优惠券', '68', '1236589443679', '0', '0', '2', '2', '0', '0', '11', '1', '0', '0', '5', '0', '0', '0', '1413988167', '1413988167', '1');
INSERT INTO `onethink_document` VALUES ('5', '1', '', '新鲜胡萝卜 蔬菜 水果 同城 送菜 到家 货到付款 只售珠三角地区', '45', '', '0', '0', '5', '2', '4', '0', '4', '1', '0', '0', '813', '0', '0', '0', '1411380420', '1413909051', '1');
INSERT INTO `onethink_document` VALUES ('8', '1', '', '【天天果园】智利青苹果12个', '57', '酸爽多汁，肉质细嫩，高品质新鲜保证', '0', '0', '5', '2', '4', '0', '7', '1', '0', '0', '500', '0', '0', '0', '1411927620', '1414093868', '1');
INSERT INTO `onethink_document` VALUES ('9', '1', '', '常鲜生 正宗菲律宾进口香蕉', '57', '', '0', '0', '5', '2', '4', '0', '9', '1', '0', '0', '162', '0', '0', '0', '1411928400', '1414093842', '1');

-- -----------------------------
-- Table structure for `onethink_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_article`;
CREATE TABLE `onethink_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `onethink_document_article`
-- -----------------------------
INSERT INTO `onethink_document_article` VALUES ('1', '0', '<h1>
	OneThink1.1开发版发布&nbsp;
</h1>
<p>
	<br />
</p>
<p>
	<strong>OneThink是一个开源的内容管理框架，基于最新的ThinkPHP3.2版本开发，提供更方便、更安全的WEB应用开发体验，采用了全新的架构设计和命名空间机制，融合了模块化、驱动化和插件化的设计理念于一体，开启了国内WEB应用傻瓜式开发的新潮流。&nbsp;</strong> 
</p>
<h2>
	主要特性：
</h2>
<p>
	1. 基于ThinkPHP最新3.2版本。
</p>
<p>
	2. 模块化：全新的架构和模块化的开发机制，便于灵活扩展和二次开发。&nbsp;
</p>
<p>
	3. 文档模型/分类体系：通过和文档模型绑定，以及不同的文档类型，不同分类可以实现差异化的功能，轻松实现诸如资讯、下载、讨论和图片等功能。
</p>
<p>
	4. 开源免费：OneThink遵循Apache2开源协议,免费提供使用。&nbsp;
</p>
<p>
	5. 用户行为：支持自定义用户行为，可以对单个用户或者群体用户的行为进行记录及分享，为您的运营决策提供有效参考数据。
</p>
<p>
	6. 云端部署：通过驱动的方式可以轻松支持平台的部署，让您的网站无缝迁移，内置已经支持SAE和BAE3.0。
</p>
<p>
	7. 云服务支持：即将启动支持云存储、云安全、云过滤和云统计等服务，更多贴心的服务让您的网站更安心。
</p>
<p>
	8. 安全稳健：提供稳健的安全策略，包括备份恢复、容错、防止恶意攻击登录，网页防篡改等多项安全管理功能，保证系统安全，可靠、稳定的运行。&nbsp;
</p>
<p>
	9. 应用仓库：官方应用仓库拥有大量来自第三方插件和应用模块、模板主题，有众多来自开源社区的贡献，让您的网站“One”美无缺。&nbsp;
</p>
<p>
	<br />
</p>
<p>
	<strong>&nbsp;OneThink集成了一个完善的后台管理体系和前台模板标签系统，让你轻松管理数据和进行前台网站的标签式开发。&nbsp;</strong> 
</p>
<p>
	<br />
</p>
<h2>
	后台主要功能：
</h2>
<p>
	1. 用户Passport系统
</p>
<p>
	2. 配置管理系统&nbsp;
</p>
<p>
	3. 权限控制系统
</p>
<p>
	4. 后台建模系统&nbsp;
</p>
<p>
	5. 多级分类系统&nbsp;
</p>
<p>
	6. 用户行为系统&nbsp;
</p>
<p>
	7. 钩子和插件系统
</p>
<p>
	8. 系统日志系统&nbsp;
</p>
<p>
	9. 数据备份和还原
</p>
<p>
	<br />
</p>
<p>
	&nbsp;[ 官方下载：&nbsp;<a href=\"http://www.onethink.cn/download.html\" target=\"_blank\">http://www.onethink.cn/download.html</a>&nbsp;&nbsp;开发手册：<a href=\"http://document.onethink.cn/\" target=\"_blank\">http://document.onethink.cn/</a>&nbsp;]&nbsp;
</p>
<p>
	<br />
</p>
<p>
	<strong>OneThink开发团队 2013~2014</strong> 
</p>', '', '0');
INSERT INTO `onethink_document_article` VALUES ('4', '0', '<div id=\"description\" class=\"tshop-psm ke-post J_DetailSection\">
	<div class=\"content\" id=\"J_DivItemDesc\">
		<p style=\"background:white;\">
			<b><span style=\"font-size:15.0pt;background:white;color:#0000cc;font-family:宋体;\">营养价值</span></b><b><span style=\"font-size:15.0pt;background:white;color:#0000cc;font-family:arial sans-serif;\"></span></b> 
		</p>
		<p style=\"background:white;text-indent:-35.0pt;\">
			<span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"><span><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></span><span style=\"font-size:14.0pt;font-family:宋体;\">韭菜的</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>营养</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">价值很高，每</span><span style=\"font-size:14.0pt;\"><span>100</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克可食用部分含</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>蛋白质</span></span></a></span><span style=\"font-size:14.0pt;\"><span>2~2.85</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克，脂肪</span><span style=\"font-size:14.0pt;\"><span>0.2~0.5</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>碳水化合物</span></span></a></span><span style=\"font-size:14.0pt;\"><span>2.4~6</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克，纤维素</span><span style=\"font-size:14.0pt;\"><span>0.6~3.2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克。还有大量的维生素，如</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>胡萝卜素</span></span></a></span><span style=\"font-size:14.0pt;\"><span>0.08~3.26</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>核黄素</span></span></a></span><span style=\"font-size:14.0pt;\"><span>0.05~0.8</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>尼克酸</span></span></a></span><span style=\"font-size:14.0pt;\"><span>0.3~1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，维生素</span><span style=\"font-size:14.0pt;\"><span>C10~62.8</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，韭菜含的矿质元素也较多，如钙</span><span style=\"font-size:14.0pt;\"><span>10~86</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，磷</span><span style=\"font-size:14.0pt;\"><span>9~51</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，铁</span><span style=\"font-size:14.0pt;\"><span>0.6~2.4</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，此外，韭菜含有挥发性的硫化丙烯，因此具有辛辣味，有促进食欲的作用。韭菜除做菜用外，还有良好的药用价值。</span></span> 
		</p>
		<p style=\"background:white;text-indent:-35.0pt;\">
			<span><span style=\"font-size:14.0pt;font-family:宋体;\"></span></span><b><span style=\"font-size:15.0pt;background:white;color:#0000cc;font-family:宋体;\">饮食宜忌</span></b><b><span style=\"font-size:15.0pt;background:white;color:#0000cc;font-family:arial sans-serif;\"></span></b> 
		</p>
		<p style=\"background:white;text-indent:35.0pt;text-align:left;\" align=\"left\">
			<span><span style=\"font-size:14.0pt;\"><span>1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、一般人群均能食用。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"background:white;text-indent:35.0pt;text-align:left;\" align=\"left\">
			<span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、适宜便秘、产后想断乳的女性、</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>寒性体质</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">等人群。</span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"background:white;text-indent:-21.0pt;text-align:left;\" align=\"left\">
			<span><span style=\"font-size:14.0pt;\"><span>3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、便秘者建议多吃，因为韭菜含有大量的</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>膳食纤维</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">，能改善肠道，润肠通便。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"background:white;text-indent:35.0pt;text-align:left;\" align=\"left\">
			<span><span style=\"font-size:14.0pt;\"><span>4</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、现代医学认为，有阳亢及热性病症的人不宜食用。</span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"background:white;text-indent:-21.0pt;text-align:left;\" align=\"left\">
			<span><span style=\"font-size:14.0pt;\"><span>5</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、韭菜的粗纤维较多，不易消化吸收，所以一次不能吃太多韭菜，否则大量粗纤维刺激肠壁，</span><span style=\"font-size:14.0pt;font-family:宋体;\">酒后尤忌</span><span style=\"font-size:14.0pt;font-family:宋体;\">。</span></span><a name=\"8_2\"></a><a name=\"sub25243_8_2\"></a><span style=\"font-size:14.0pt;\"></span> 
		</p>
		<p>
			<span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"><span><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>6</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、韭菜偏热性，多食易上火，因此阴虚火旺者不宜多吃。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:35.0pt;\">
			<span><span style=\"font-size:14.0pt;\"><span>7</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、胃虚有热、消化不良不宜食用。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-21.0pt;\">
			<span><span style=\"font-size:14.0pt;\"><span>8</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、夏韭老化，纤维多而粗造，不易被人肠胃消化吸收，加之夏季胃肠蠕动，功能降低，多会引起胃肠不适或腹泻，因此夏季热时不宜多食。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:35.0pt;\">
			<span><span style=\"font-size:14.0pt;\"><span>9</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、熟的韭菜不能隔夜吃</span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p>
			<a name=\"11_2\"></a><a name=\"sub25243_11_2\"></a><b><span style=\"font-size:15.0pt;color:#0000cc;font-family:宋体;\">推荐食谱</span></b><b><span style=\"font-size:15.0pt;color:#0000cc;\"></span></b> 
		</p>
		<p style=\"text-indent:27.75pt;\">
			<span><b><span style=\"font-size:14.0pt;background:white;font-family:宋体;\">韭菜炒蛋</span></b><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-35.0pt;\">
			<span><span style=\"font-size:14.0pt;font-family:宋体;\">【原料】：韭菜</span><span style=\"font-size:14.0pt;\"><span>4</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">两（约</span><span style=\"font-size:14.0pt;\"><span>200</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克），大鸡蛋</span><span style=\"font-size:14.0pt;\"><span>3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">只，调料：</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>生油</span></span></a></span><span style=\"font-size:14.0pt;\"><span>3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">汤匙，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>生粉</span></span></a></span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">茶匙，清水</span><span style=\"font-size:14.0pt;\"><span>1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">汤匙，鸡粉</span><span style=\"font-size:14.0pt;\"><span>1/4</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">茶匙，麻油</span><span style=\"font-size:14.0pt;\"><span>1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">茶匙，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>胡椒粉</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">少许。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-35.0pt;\">
			<span><span style=\"font-size:14.0pt;font-family:宋体;\">【做法】：</span><span style=\"font-size:14.0pt;\"><span>1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、韭菜洗净切小段；</span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:28.0pt;\">
			<span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、生粉用水拌匀制成生粉水，待用；</span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:28.0pt;\">
			<span><span style=\"font-size:14.0pt;\"><span>3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、将调料、韭菜、生粉水一起拌匀；</span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:28.0pt;\">
			<span><span style=\"font-size:14.0pt;\"><span>4</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、在大碗内搅散鸡蛋；</span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-14.0pt;\">
			<span><span style=\"font-size:14.0pt;\"><span>5</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、炒锅烧热，放入三汤匙生油，待油热后，倒入韭菜、蛋液，快炒至凝固，即可装盘食用。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-14.0pt;\">
			<span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:28.0pt;\">
			<span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><b><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>豆丝韭菜</span></span></b></a></span><span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-49.0pt;\">
			<span><span style=\"font-size:14.0pt;font-family:宋体;\">【原料】：韭菜</span><span style=\"font-size:14.0pt;\"><span>500</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>土豆</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">（黄皮）</span><span style=\"font-size:14.0pt;\"><span>200</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克。调料：胡麻油</span><span style=\"font-size:14.0pt;\"><span>15</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克，盐</span><span style=\"font-size:14.0pt;\"><span>3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>味精</span></span></a></span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-84.0pt;\">
			<span><span style=\"font-size:14.0pt;font-family:宋体;\">【做法】：</span><span style=\"font-size:14.0pt;\"><span>1.</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">韭菜洗净后切成段，放入沸水锅中焯一下，沥干水分；土豆洗净后去皮切成丝。</span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-14.0pt;\">
			<span><span style=\"font-size:14.0pt;\"><span>2.</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">花椒油、味精、</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>精盐</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">、韭菜段和土豆丝一起放入盆内，拌匀装盘即可。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span></span><span><span style=\"font-size:14.0pt;font-family:宋体;\"></span></span> 
		</p>
		<p>
			<b><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><span>&nbsp;</span></span></b> 
		</p>
		<p style=\"text-indent:29.1pt;\">
			<span><b><span style=\"font-size:14.0pt;background:white;font-family:宋体;\">韭菜炒咸猪肉</span></b><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-49.0pt;\">
			<span><span style=\"font-size:14.0pt;font-family:宋体;\">【原料】：</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>咸猪肉</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">片，韭菜，新鲜干</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>葱头</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">甲片，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>红萝卜</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">花，炸蒜片，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>小葱</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">度。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-42.0pt;\">
			<span><span style=\"font-size:14.0pt;font-family:宋体;\">【做法】：锅内烧净</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>色拉油</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">至</span><span style=\"font-size:14.0pt;\"><span>7</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">成热，逐片放入腌制好的咸猪肉片后离火，炸成略脆状后倒出。将韭菜花飞水后，加入少许味水略炒后倒出。锅内放少许油，倒入料头炒香，加入炸好咸猪肉片，韭菜花，料酒，味水芡汁（带少许</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>蚝油</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">），快速炒匀后亮油起锅。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p>
			<b><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><span>&nbsp;</span></span></b> 
		</p>
		<p style=\"text-indent:29.1pt;\">
			<span><b><span style=\"font-size:14.0pt;background:white;font-family:宋体;\">培根炒韭菜</span></b><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:55.45pt;\">
			<span><span style=\"font-size:14.0pt;font-family:宋体;\">【原料】：</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>韭菜</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">美式</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>培根</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">若干条、</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>食用油</span></span></a></span><span style=\"font-size:14.0pt;background:white;font-family:宋体;\">、</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>盐</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">、</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>糖</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">。　</span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-77.0pt;\">
			<span><span style=\"font-size:14.0pt;font-family:宋体;\">【做法】：</span><span style=\"font-size:14.0pt;\"><span>1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、培根整条放入不粘锅中，小火煎至金黄肉脆，肥油全部渗出。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-14.0pt;\">
			<span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、取出培根条，切小片备用。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-14.0pt;\">
			<span><span style=\"font-size:14.0pt;\"><span>3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、煎培根的原锅中添加适量的食用油（视韭菜量），油热后加入韭菜快速翻炒。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
		</p>
		<p style=\"text-indent:-14.0pt;\">
			<span><span style=\"font-size:14.0pt;\"><span>4</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、韭菜断生后，立即加入培根片，少许盐，糖调味，出锅装盘即可。</span></span> 
		</p>
	</div>
</div>', '', '0');
INSERT INTO `onethink_document_article` VALUES ('12', '0', '1236589443679', '', '0');

-- -----------------------------
-- Table structure for `onethink_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_download`;
CREATE TABLE `onethink_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';

-- -----------------------------
-- Records of `onethink_document_download`
-- -----------------------------
INSERT INTO `onethink_document_download` VALUES ('2', '0', '<blockquote style=\"background-color:#F4F5F7;color:#999999;font-size:16px;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;\">
	题，并作了大量的改进，是一个值得升级的版本！
</blockquote>
<img src=\"http://yun.topthink.com/Uploads/Editor/2014-07-22/53ce00d943be3.png\" alt=\"\" /><br />
<span style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;background-color:#F4F6F8;font-size:18px;\"><span style=\"color:#E53333;\"><b>OneThink会一如既往的让你的开发变得更简单！</b></span></span><br />
<br />
<span style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;background-color:#F4F6F8;font-size:24px;\">1.1开发版本会保持快速迭代，欢迎大家多参与。</span><br />
<span style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;background-color:#F4F6F8;font-size:24px;\"> 
<blockquote style=\"background-color:#F4F5F7;color:#999999;font-size:16px;\">
	<b><span style=\"color:#E53333;\">注意：最新的开发版本数据库驱动用PDO重写了，所以如果之前配置的是PDO驱动类型的话，请改成具体的数据库类型。</span></b> 
</blockquote>
</span><br />
<span style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;background-color:#F4F6F8;font-size:24px;\">[&nbsp;更新列表&nbsp;]</span><br />
<span style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;background-color:#F4F6F8;font-size:24px;\"><b><span style=\"font-size:18px;\"><b>1.1.140825_dev&nbsp;[2014.8.25]：</b></span></b></span><br />
<ul style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;font-size:16px;background-color:#F4F6F8;\">
	<li>
		安装SQL文件更新
	</li>
	<li>
		修复七牛上传驱动的命名空间
	</li>
	<li>
		修正数据库备份类
	</li>
	<li>
		修正一些警告错误
	</li>
	<li>
		修正模板大小写问题
	</li>
	<li>
		修正导航的授权显示
	</li>
	<li>
		更新数据库驱动
	</li>
	<li>
		hooks表增加status字段，修正使用lists方法查询时的bug
	</li>
	<li>
		支持无钩子的插件安装
	</li>
	<li>
		改进菜单获取方法
	</li>
	<li>
		优化菜单显示&nbsp;采用session缓存&nbsp;修改菜单后需要重启才能生效
	</li>
</ul>
<span style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;background-color:#F4F6F8;font-size:24px;\"><b><span style=\"font-size:18px;\"><b>1.1.140817_dev&nbsp;[2014.8.17]：</b></span></b></span><br />
<ul style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;font-size:16px;background-color:#F4F6F8;\">
	<li>
		修正一些警告错误
	</li>
	<li>
		修正后台封面图片上传的显示问题
	</li>
	<li>
		后台生成模型的时候支持指定名称和标识
	</li>
	<li>
		修正后台模型生成获取数据表的错误
	</li>
	<li>
		支持更准确的SQL记录
	</li>
	<li>
		修正参数绑定可能导致的冲突问题
	</li>
	<li>
		修正安装程序用户表写入生日字段默认值错误
	</li>
	<li>
		改进Admin模块的ModelModel类的generate方法
	</li>
	<li>
		改进article:list标签的category属性可以包含当前分类
	</li>
	<li>
		修正数据备份操作
	</li>
</ul>
<span style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;background-color:#F4F6F8;font-size:24px;\"><b><span style=\"font-size:18px;\"><b>1.1.140809_dev&nbsp;[2014.8.9]：</b></span></b></span><br />
<ul style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;font-size:16px;background-color:#F4F6F8;\">
	<li>
		升级核心框架，驱动类库采用PDO重写
	</li>
	<li>
		修正后台文档列表查询的状态查询问题
	</li>
	<li>
		去掉后台BaseLogic类的lists方法
	</li>
	<li>
		简化后台模块的DocumentModel类，去掉部分不需要的方法
	</li>
	<li>
		改进文档模型的name标识检测&nbsp;根分类下面不能重名
	</li>
	<li>
		独立模型数据列表页改进
	</li>
	<li>
		Home模块的Logic类改进
	</li>
	<li>
		修正模型的属性定义中使用函数定义的问题
	</li>
	<li>
		模板调整和删除一些无用的数据
	</li>
</ul>
<span style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;background-color:#F4F6F8;font-size:24px;\"><b><span style=\"font-size:18px;\"><b>1.1.140726_dev&nbsp;[2014.7.26]：</b></span></b></span><br />
<ul style=\"color:#333333;font-family:\'Century Gothic\', \'MicroSoft YaHei\', \'hiragino sans GB\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;font-size:16px;background-color:#F4F6F8;\">
	<li>
		文档模型的扩展属性支持在属性管理中设置是否必须、自动验证和自动完成，并且会自动和对应的Logic类合并；
	</li>
	<li>
		安装完成后的后台访问错误修正；
	</li>
	<li>
		修正多处警告错误；
	</li>
</ul>', '', '1', '0', '23324');
INSERT INTO `onethink_document_download` VALUES ('3', '0', '<ul style=\"font-family:宋体, arial, sans-serif;color:#232426;background-color:#FFFFFF;\">
	<li style=\"color:#777777;\">
		上映年代：2014&nbsp;&nbsp;状态：全集
	</li>
	<li style=\"color:#777777;\">
		类型：
	</li>
	<li style=\"color:#777777;\">
		主演：<a href=\"http://www.beiwo.tv/index.php?s=vod-search-actor-%E6%B2%B3%E6%AD%A3%E5%AE%87.html\" target=\"_blank\">河正宇</a>&nbsp;<a href=\"http://www.beiwo.tv/index.php?s=vod-search-actor-%E5%A7%9C%E4%B8%9C%E5%85%83.html\" target=\"_blank\">姜东元</a>&nbsp;<a href=\"http://www.beiwo.tv/index.php?s=vod-search-actor-%E5%B0%B9%E6%99%BA%E6%85%A7.html\" target=\"_blank\">尹智慧</a>&nbsp;<a href=\"http://www.beiwo.tv/index.php?s=vod-search-actor-%E6%9D%8E%E7%92%9F%E8%8D%A3.html\" target=\"_blank\">李璟荣</a>
	</li>
	<li style=\"color:#777777;\">
		地区：韩国<img src=\"/111/Uploads/Editor/2014-09-18/5419eb8071136.png\" alt=\"\" />
	</li>
	<li style=\"color:#777777;\">
		更新日期：2014-09-08&nbsp;&nbsp;
	</li>
</ul>
<p>
	剧情： 描绘了19世纪朝鲜时代抢夺贪官污吏钱财救济百姓们的侠盗与士大夫们之间的对决。...<a href=\"http://www.beiwo.tv/vod/21258/#desc\">详细剧情</a>
</p>
<p>
	<br />
</p>', '', '2', '0', '206166');

-- -----------------------------
-- Table structure for `onethink_document_product`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_product`;
CREATE TABLE `onethink_document_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `price` varchar(255) NOT NULL DEFAULT '1.00' COMMENT '价格',
  `content` text NOT NULL COMMENT '内容详细描述',
  `weight` varchar(255) NOT NULL DEFAULT '500' COMMENT '净重',
  `totalsales` int(10) unsigned NOT NULL COMMENT '总销量',
  `area` varchar(255) NOT NULL DEFAULT '中国大陆' COMMENT '产地',
  `ads_pic_id` int(10) unsigned NOT NULL COMMENT '首页幻灯大图',
  `adtitle` varchar(255) NOT NULL COMMENT '广告宣传标题',
  `yprice` varchar(255) NOT NULL COMMENT '原价',
  `mark` varchar(255) NOT NULL COMMENT '附加标签',
  `unionid` varchar(255) NOT NULL COMMENT '关联商品',
  `num` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '库存',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `onethink_document_product`
-- -----------------------------
INSERT INTO `onethink_document_product` VALUES ('5', '2.98', '<p style=\"background:white;text-align:left;\" align=\"left\">
	<b><span style=\"font-size:15.0pt;background:white;color:#0000cc;font-family:宋体;\">营养成份</span></b><b><span style=\"font-size:15.0pt;background:white;color:#0000cc;font-family:arial sans-serif;\"></span></b> 
</p>
<p style=\"text-indent:-35.0pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"><span><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></span><span style=\"font-size:14.0pt;font-family:宋体;\">每</span><span style=\"font-size:14.0pt;\"><span>100</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克胡萝卜中，约含</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>蛋白质</span></span></a></span><span style=\"font-size:14.0pt;\"><span>0.6</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>脂肪</span></span></a></span><span style=\"font-size:14.0pt;\"><span>0.3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克，糖类</span><span style=\"font-size:14.0pt;\"><span>7.6</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">～</span><span style=\"font-size:14.0pt;\"><span>8.3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克，铁</span><span style=\"font-size:14.0pt;\"><span>0.6</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>维生素</span></span><span style=\"color:windowtext;text-decoration:none;\">A</span><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>原</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">（胡萝卜素）</span><span style=\"font-size:14.0pt;\"><span>1.35</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">～</span><span style=\"font-size:14.0pt;\"><span>17.25</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>维生素</span></span><span style=\"color:windowtext;text-decoration:none;\">B1</span></a></span><span style=\"font-size:14.0pt;\"><span>0.02</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">～</span><span style=\"font-size:14.0pt;\"><span>0.04</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>维生素</span></span><span style=\"color:windowtext;text-decoration:none;\">B2</span></a></span><span style=\"font-size:14.0pt;\"><span>0.04</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">～</span><span style=\"font-size:14.0pt;\"><span>0.05</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，维生素</span><span style=\"font-size:14.0pt;\"><span>C12</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">毫克，热量</span><span style=\"font-size:14.0pt;\"><span>150.7</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">千焦，另含果胶、淀粉、无机盐和多种氨基酸。各类品种中尤以深橘红色胡萝卜素含量最高，各种胡萝卜所含能量在</span><span style=\"font-size:14.0pt;\"><span>79.5</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">干焦～</span><span style=\"font-size:14.0pt;\"><span>1339.8</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">千焦之间。胡萝卜是一种质脆味美、营养丰富的家常蔬菜，素有</span><span style=\"font-size:14.0pt;\"><span>“</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">小人参</span><span style=\"font-size:14.0pt;\"><span>”</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">之称。胡萝卜富含糖类、脂肪、挥发油、胡萝卜素、维生素</span><span style=\"font-size:14.0pt;\"><span>A</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、维生素</span><span style=\"font-size:14.0pt;\"><span>B1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、维生素</span><span style=\"font-size:14.0pt;\"><span>B2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>花青素</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">、钙、铁等营养成分。</span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"background:white;text-align:left;\" align=\"left\">
	<b><span style=\"font-size:15.0pt;background:white;color:#0000cc;font-family:宋体;\">饮食宜忌</span></b><span style=\"font-size:14.0pt;\"></span> 
</p>
<ul>
	<li>
		<span style=\"font-size:14.0pt;\"></span><span><span style=\"font-size:14.0pt;font-family:宋体;\">胡萝卜也适宜于</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>皮肤干燥</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">、粗糙，或患毛发苔藓、黑头粉刺、角化型</span><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"><a><span style=\"color:windowtext;font-family:宋体;text-decoration:none;\"><span>湿疹</span></span></a></span><span style=\"font-size:14.0pt;font-family:宋体;\">者食用。</span><span style=\"font-size:14.0pt;\"></span></span> 
	</li>
	<li>
		<span style=\"font-size:14.0pt;\"></span><span><span style=\"font-size:14.0pt;font-family:宋体;\">适宜癌症、高血压、夜盲症、干眼症患者、营养不良、食欲不振者、皮肤粗糙者。</span><span style=\"font-size:14.0pt;\"></span></span> 
	</li>
	<li>
		<span style=\"font-size:14.0pt;\"></span><span><span style=\"font-size:14.0pt;font-family:宋体;\">烹调胡萝卜时，不要加醋，以免胡萝卜素损失。另外不要过量食用。大量摄入胡萝卜素会令皮肤的色素产生变化，变成橙黄色。</span><span style=\"font-size:14.0pt;\"></span></span> 
	</li>
	<li>
		<span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;\"><span><span>&nbsp;</span></span></span></span><span><span style=\"font-size:14.0pt;font-family:宋体;\">不宜食用切碎后水洗或久浸泡于水中的萝卜。</span><span style=\"font-size:14.0pt;\"></span></span> 
	</li>
	<li>
		<span style=\"font-size:14.0pt;\"></span><span><span style=\"font-size:14.0pt;font-family:宋体;\">服用双氢克尿塞时不宜食用。</span><span style=\"font-size:14.0pt;\"></span></span> 
	</li>
	<li>
		<span style=\"font-size:14.0pt;\"></span><span><span style=\"font-size:14.0pt;font-family:宋体;\">食时咀嚼时间不宜过短。</span><span style=\"font-size:14.0pt;\"></span></span> 
	</li>
	<li>
		<span style=\"font-size:14.0pt;\"></span><span><span style=\"font-size:14.0pt;font-family:宋体;\">不可与白萝卜同时食用。</span><span style=\"font-size:14.0pt;\"></span></span> 
	</li>
	<li>
		<span style=\"font-size:14.0pt;\"></span><span><span style=\"font-size:14.0pt;font-family:宋体;\">不宜与富含维生素</span><span style=\"font-size:14.0pt;\"><span>C</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">的蔬菜（如菠菜、油菜、花菜、番茄、辣椒等），水果（如柑橘、柠檬、草莓、枣子等）同食破坏维生素</span><span style=\"font-size:14.0pt;\"><span>C</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">，降低营养价值。</span><span style=\"font-size:14.0pt;\"></span></span> 
	</li>
	<li>
		<span style=\"font-size:14.0pt;\"></span><span><span style=\"font-size:14.0pt;font-family:宋体;\">禁忌生食。胡萝卜虽是蔬菜，但只有烹调，其所含的类萝卜素才较稳定。按照我们的炒菜方法，营养可保存</span><span style=\"font-size:14.0pt;\"><span>76%</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">至</span><span style=\"font-size:14.0pt;\"><span>94%</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">。因此生吃胡萝卜，类萝卜素因没有脂肪而很难被吸收，从而造成浪费。</span><span style=\"font-size:14.0pt;\"></span></span> 
	</li>
	<li>
		<span style=\"font-size:14.0pt;\"></span><span><span style=\"font-size:14.0pt;font-family:宋体;\">研究发现，妇女过多吃胡萝卜后，摄入的大量胡萝卜素会引起闭经和抑制卵巢的正常排卵功能。因此</span><b><span style=\"font-size:14.0pt;background:white;font-family:宋体;\">欲怀孕的妇女不宜多吃胡萝卜</span></b><span style=\"font-size:14.0pt;font-family:宋体;\">。</span><span style=\"font-size:14.0pt;\"></span></span> 
	</li>
</ul>
<p style=\"background:white;\">
	<a name=\"3_1\"></a><a name=\"sub17967_3_1\"></a><b><span style=\"font-size:15.0pt;background:white;color:#0000cc;font-family:宋体;\">作用</span></b><b><span style=\"font-size:15.0pt;background:white;color:#0000cc;font-family:arial sans-serif;\"></span></b> 
</p>
<p>
	<span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"><span><span>&nbsp;</span>1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、益肝明目；</span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、利膈宽肠；</span><span style=\"font-size:14.0pt;\"><span><span>3</span></span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、健脾除疳；</span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:42.0pt;\">
	<span><span style=\"font-size:14.0pt;\"><span>4</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、增强免疫功能；</span><span style=\"font-size:14.0pt;\"><span><span>5</span></span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、降糖降脂。</span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p>
	<a name=\"3_2\"></a><a name=\"sub17967_3_2\"></a><a name=\"8_1\"></a><a name=\"sub17967_8_1\"></a><b><span style=\"font-size:15.0pt;color:#0000cc;font-family:宋体;\">推荐食谱</span></b><b><span style=\"font-size:15.0pt;color:#0000cc;\"></span></b> 
</p>
<p style=\"background:white;text-indent:29.1pt;\">
	<a name=\"8_3\"></a><a name=\"sub17967_8_3\"></a><a name=\"8_4\"></a><a name=\"sub17967_8_4\"></a><span><b><span style=\"font-size:14.0pt;background:white;font-family:宋体;\">胡萝卜蛋饼</span></b><b><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"></span></b></span> 
</p>
<p style=\"text-indent:55.6pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\">【原料】：胡萝卜、苦瓜、鸡蛋、葱花　</span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:55.6pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\">【调料】：盐、胡椒粉、油</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:55.6pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\">【做法】：</span><span style=\"font-size:14.0pt;\"><span>1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、胡萝卜切小丁、苦瓜切小丁，</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-21.0pt;\">
	<span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、鸡蛋打散，放入，苦瓜、胡萝卜、加盐、胡椒粉、拌匀，</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:7.0pt;\">
	<span><span style=\"font-size:14.0pt;\"><span>3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、锅中放油，</span><span style=\"font-size:14.0pt;\"><span>5</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">成油温时放入蛋液两面煎熟即可。</span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"background:white;text-indent:29.1pt;\">
	<a name=\"8_5\"></a><a name=\"sub17967_8_5\"></a><span><b><span style=\"font-size:14.0pt;background:white;font-family:宋体;\">香烧胡萝卜</span></b><b><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"></span></b></span> 
</p>
<p style=\"text-indent:-119.0pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"><span><span>&nbsp;&nbsp;&nbsp;</span></span></span><span style=\"font-size:14.0pt;font-family:宋体;\">【原料】：胡萝卜</span><span style=\"font-size:14.0pt;\"><span>3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">根、生抽</span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">小勺、白糖</span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">小勺、老抽</span><span style=\"font-size:14.0pt;\"><span>1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">小勺（用家里的白瓷汤勺就行）、盐少许。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:56.0pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\">【做法】：</span><span style=\"font-size:14.0pt;\"><span>1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、胡萝卜去皮，切滚刀块，不宜太大。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-21.0pt;\">
	<span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、两小勺生抽，一小勺老抽，两小勺白糖，少许的盐，混合调成汁。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-21.0pt;\">
	<span><span style=\"font-size:14.0pt;\"><span>3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、平底锅倒油烧热，下入胡萝卜块，中小火慢慢的烧，中间不加水，也不用盖锅盖，将胡萝卜烧软；</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-21.0pt;\">
	<span><span style=\"font-size:14.0pt;\"><span>4</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、待胡萝卜的棱角变圆，变得绵软并且没有一点生味。胡萝卜烧透后倒入调味汁，待汤汁烧至略干，香味渗入胡萝卜就可以关火了。</span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"background:white;text-indent:29.1pt;\">
	<a name=\"8_6\"></a><a name=\"sub17967_8_6\"></a><a name=\"8_7\"></a><a name=\"sub17967_8_7\"></a><span><b><span style=\"font-size:14.0pt;background:white;font-family:宋体;\">炝炒胡萝卜片</span></b><b><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"></span></b></span> 
</p>
<p style=\"text-indent:-133.0pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"><span><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></span><span style=\"font-size:14.0pt;font-family:宋体;\">【原料】：胡萝卜</span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">根约</span><span style=\"font-size:14.0pt;\"><span>300</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克、蒜苗（青蒜）</span><span style=\"font-size:14.0pt;\"><span>50</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克、干辣椒</span><span style=\"font-size:14.0pt;\"><span>15</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">克、盐适量、油。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-84.0pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\">【做法】：</span><span style=\"font-size:14.0pt;\"><span>1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、将胡萝卜洗净去皮，切成菱形片（先斜切成段，在纵切成片）；</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-21.0pt;\">
	<span><span style=\"font-size:14.0pt;\"><span>2</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、锅中放入适量水和少量油，将胡萝卜片放入煮熟，捞出沥干待用；</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-21.0pt;\">
	<span><span style=\"font-size:14.0pt;\"><span>3</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、蒜苗洗净拍松切成段，干辣椒去籽切段或者丝；</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-21.0pt;\">
	<span><span style=\"font-size:14.0pt;\"><span>4</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、炒锅烧热，放入少量油，放入干辣椒炒香；</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-21.0pt;\">
	<span><span style=\"font-size:14.0pt;\"><span>5</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、再放入蒜苗炒香；</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-21.0pt;\">
	<span><span style=\"font-size:14.0pt;\"><span>6</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">、最后加入胡萝卜片炒匀，加盐调味即可。</span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"background:white;text-indent:28.95pt;\">
	<a name=\"8_8\"></a><a name=\"sub17967_8_8\"></a><a name=\"9_1\"></a><a name=\"sub17967_9_1\"></a><a name=\"9_2\"></a><a name=\"sub17967_9_2\"></a><a name=\"9_3\"></a><a name=\"sub17967_9_3\"></a><span><b><span style=\"font-size:14.0pt;background:white;font-family:宋体;\">胡萝卜白米香粥</span></b><span style=\"font-size:14.0pt;background:white;font-family:宋体;\">（</span><span style=\"font-size:14.0pt;font-family:宋体;\">适合</span><span style=\"font-size:14.0pt;\"><span>5</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">个月以上的宝宝）</span><b><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"></span></b></span> 
</p>
<p style=\"text-indent:56.0pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\">【原料】：胡萝卜</span><span style=\"font-size:14.0pt;\"><span>1</span></span><span style=\"font-size:14.0pt;font-family:宋体;\">根，煮到烂熟的白米粥半小碗。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-63.0pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\">【做法】：把胡萝卜清洗干净后，去皮煮熟，然后和白米粥一起压成泥状，也可采用果汁机打成泥状，经过加热就可以喂宝贝了。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-63.0pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\">【贴心小提醒】：也可以把胡萝卜和白米饭一起煮到烂熟，再用勺子压碎，待放凉后就可喂宝贝了。</span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"background:white;text-indent:29.1pt;\">
	<a name=\"8_2\"></a><a name=\"sub17967_8_2\"></a><span><b><span style=\"font-size:14.0pt;background:white;font-family:宋体;\">胡萝卜香泥</span></b><b><span style=\"font-size:14.0pt;background:white;font-family:arial sans-serif;\"></span></b></span> 
</p>
<p>
	<span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"><span><span>&nbsp;&nbsp;&nbsp;</span></span></span><span style=\"font-size:14.0pt;font-family:宋体;\">【原料】：新鲜胡萝卜半根。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<p style=\"text-indent:-63.0pt;\">
	<span><span style=\"font-size:14.0pt;font-family:宋体;\">【做法】：先把胡萝卜清洗干净，煮熟或蒸熟，然后将其放凉后去皮，再用压泥器压成碎泥状，就可以喂宝贝吃了。</span><span style=\"font-size:14.0pt;\"></span><span style=\"font-size:14.0pt;font-family:宋体;\"></span><span style=\"font-size:14.0pt;\"></span></span> 
</p>
<span><span style=\"font-size:14.0pt;font-family:宋体;\">【贴心小提醒】：胡萝卜虽然富有营养，但吃得适量最好。如果给宝贝吃得过多，容易使皮肤变黄。</span></span><br />', '500', '15', '中国大陆', '8', 'Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.', '', '2', '8,9', '1');
INSERT INTO `onethink_document_product` VALUES ('8', '10.00', '<div id=\"J_DcTopRightWrap\" style=\"margin:0px;padding:0px;color:#404040;font-family:tahoma, arial, 微软雅黑, sans-serif;background-color:#FFFFFF;\">
	<div id=\"J_DcTopRight\" class=\"J_DcAsyn tb-shop\" style=\"margin:0px;padding:0px;\">
		<div class=\"J_TModule\" id=\"shop8751140001\" style=\"margin:0px;padding:0px;\">
			<div class=\"skin-box tb-module tshop-pbsm tshop-pbsm-shop-self-defined\" style=\"margin:0px;padding:0px;\">
				<div class=\"skin-box-bd clear-fix\" style=\"margin:0px;padding:0px;border:0px solid #FFFFFF;color:#828282;background:none;\">
					<span> 
					<p>
						<img src=\"http://img03.taobaocdn.com/imgextra/i3/738580955/TB2oT.ZapXXXXaxXXXXXXXXXXXX-738580955.jpg_.webp\" /> 
					</p>
</span> 
				</div>
<s class=\"skin-box-bt\"><b></b></s> 
			</div>
		</div>
		<div class=\"J_TModule\" id=\"shop8825085575\" style=\"margin:0px;padding:0px;\">
			<div class=\"skin-box tb-module tshop-pbsm tshop-pbsm-shop-self-defined\" style=\"margin:0px;padding:0px;\">
				<s class=\"skin-box-tp\"><b></b></s> 
				<div class=\"skin-box-bd clear-fix\" style=\"margin:0px;padding:0px;border:0px solid #FFFFFF;color:#828282;background:none;\">
					<span> 
					<p>
						<a href=\"http://detail.tmall.com/item.htm?spm=a220z.1000880.0.0.UoC3cM&id=35904185523&scene=taobao_shop\" target=\"_blank\"><img src=\"http://img03.taobaocdn.com/imgextra/i3/738580955/TB2AEVlaFXXXXbOXXXXXXXXXXXX-738580955.jpg_.webp\" /></a> 
					</p>
</span> 
				</div>
<s class=\"skin-box-bt\"><b></b></s> 
			</div>
		</div>
	</div>
</div>
<div id=\"description\" class=\"J_DetailSection tshop-psm tshop-psm-bdetaildes\" style=\"margin:0px;padding:0px;color:#404040;font-family:tahoma, arial, 微软雅黑, sans-serif;background-color:#FFFFFF;\">
	<div class=\"content ke-post\" style=\"margin:10px 0px 0px;padding:0px;font-size:14px;font-family:tahoma, arial, 宋体, sans-serif;\">
		<div style=\"margin:0px;padding:0px;\">
			<span><span style=\"font-weight:700;\"><span style=\"font-size:18px;\">智利青苹果</span></span><br />
</span> 
		</div>
		<div style=\"margin:0px;padding:0px;\">
			<p>
				<span><span style=\"font-weight:700;\"><img class=\"ke_anchor\" id=\"ids-tag-m-35171\" src=\"http://a.tbcdn.cn/kissy/1.0.0/build/imglazyload/spaceball.gif\" style=\"height:1px;\" />产品简介</span><br />
智利苹果色泽艳丽，颜色从青绿到浅绿都有，也可能会略带粉红色。口感上则相当酸，是喜欢酸味朋友们的大爱，爽脆多汁，口味鲜美，吃法较多。&nbsp;</span> 
			</p>
		</div>
		<div style=\"margin:0px;padding:0px;\">
			<span><span style=\"font-weight:700;\">温馨提示</span><br />
</span> 
		</div>
		<div style=\"margin:0px;padding:0px;\">
			<span>此款产地为智利。</span> 
		</div>
		<div style=\"margin:0px;padding:0px;\">
			<span>冰箱冷藏保存时间会更久，保存时表皮不要沾水。苹果皮中含有丰富营养素，建议连皮一起吃。</span> 
			<p>
				<img align=\"absmiddle\" src=\"http://img02.taobaocdn.com/imgextra/i2/738580955/T2zOhCXfdOXXXXXXXX-738580955.jpg\" /><img align=\"absmiddle\" src=\"http://img04.taobaocdn.com/imgextra/i4/738580955/T2Zz1aXXtdXXXXXXXX-738580955.jpg\" /><img align=\"absmiddle\" src=\"http://img01.taobaocdn.com/imgextra/i1/738580955/T2VPCuXc4cXXXXXXXX-738580955.jpg\" /><img align=\"absmiddle\" src=\"http://img04.taobaocdn.com/imgextra/i4/738580955/T2ZwXBXl8NXXXXXXXX-738580955.jpg\" /> 
			</p>
			<p>
				<img align=\"absmiddle\" src=\"http://img04.taobaocdn.com/imgextra/i4/738580955/T2MmJyXi0OXXXXXXXX-738580955.jpg_.webp\" /><img class=\"ke_anchor\" id=\"ids-tag-m-35173\" src=\"http://a.tbcdn.cn/kissy/1.0.0/build/imglazyload/spaceball.gif\" style=\"height:1px;\" /><img align=\"absmiddle\" src=\"http://img01.taobaocdn.com/imgextra/i1/738580955/T2yn4DXj8OXXXXXXXX-738580955.jpg_.webp\" /> 
			</p>
		</div>
		<p>
			<img class=\"ke_anchor\" id=\"ids-tag-m-35176\" src=\"http://a.tbcdn.cn/kissy/1.0.0/build/imglazyload/spaceball.gif\" style=\"height:1px;\" /><img align=\"absmiddle\" src=\"http://img03.taobaocdn.com/imgextra/i3/738580955/T28tdGXd0OXXXXXXXX-738580955.jpg_.webp\" /> 
		</p>
	</div>
</div>', '500', '11', '中国大陆', '8', '正宗进口青苹果水果酸甜新鲜水果', '', '', '', '1');
INSERT INTO `onethink_document_product` VALUES ('9', '5.00', '<h2 align=\"center\" style=\"font-family:tahoma, arial, 宋体, sans-serif;background-color:#FFFFFF;\">
	配送范围：目前江浙沪（其他城市或者偏远乡镇村目前不配送，谢谢）
</h2>
<p align=\"center\" style=\"font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">
	<img src=\"http://gd1.alicdn.com/imgextra/i1/595478579/T2gtbxXINaXXXXXXXX_!!595478579.jpg\" /> 
</p>
<p align=\"center\" style=\"font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">
	<img src=\"http://gd2.alicdn.com/imgextra/i2/595478579/T2yOPCXKFaXXXXXXXX_!!595478579.jpg\" /><img src=\"http://gd3.alicdn.com/imgextra/i3/595478579/T2S52CXMlaXXXXXXXX_!!595478579.jpg\" /><img src=\"http://gd3.alicdn.com/imgextra/i3/595478579/T2XmrCXLNaXXXXXXXX_!!595478579.jpg\" /> 
</p>
<p align=\"center\" style=\"font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">
	<img src=\"http://gd3.alicdn.com/imgextra/i3/595478579/T2poTvXMpaXXXXXXXX_!!595478579.jpg\" /> 
</p>', '500', '0', '中国大陆', '10', '常鲜生 菲律宾进口香蕉 都乐香蕉 新鲜水果 整箱批发', '', '', '', '1');

-- -----------------------------
-- Table structure for `onethink_favortable`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_favortable`;
CREATE TABLE `onethink_favortable` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(5) NOT NULL,
  `goodid` int(100) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `num` int(11) DEFAULT '1',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_favortable`
-- -----------------------------
INSERT INTO `onethink_favortable` VALUES ('13', '1', '8', '2014-10-22 19:14:47', '1');
INSERT INTO `onethink_favortable` VALUES ('14', '1', '9', '2014-10-25 01:16:34', '1');

-- -----------------------------
-- Table structure for `onethink_fcoupon`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_fcoupon`;
CREATE TABLE `onethink_fcoupon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `price` varchar(50) NOT NULL COMMENT '金额',
  `code` varchar(255) NOT NULL COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '列表绑定模型',
  `model_sub` varchar(100) NOT NULL DEFAULT '' COMMENT '子文档绑定模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` int(4) DEFAULT NULL COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  `ismenu` int(11) DEFAULT NULL COMMENT '无限极分类调用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_fcoupon`
-- -----------------------------
INSERT INTO `onethink_fcoupon` VALUES ('1', '645645', '肯德基', '0', '0', '10', '30', '6fsgwcjf', '', '', '', '', '', '', '', '', '0', '1', '1', '0', '0', '', '', '1414012468', '1414174845', '1', '5', '');
INSERT INTO `onethink_fcoupon` VALUES ('2', '645465', '麦当劳', '0', '0', '10', '6644', '453ljnq7', '', '', '', '', '', '', '', '', '0', '1', '1', '0', '0', '', '', '1414012758', '1414174944', '1', '11', '');
INSERT INTO `onethink_fcoupon` VALUES ('3', '64645', '麦考林', '0', '0', '10', '656', '4nm34itt', '', '', '', '', '', '', '', '', '0', '1', '1', '0', '0', '', '', '1414012817', '1414175369', '1', '14', '');
INSERT INTO `onethink_fcoupon` VALUES ('4', '564456', '小肥羊', '0', '0', '10', '65445', 'chmvc29z', '', '', '', '', '', '', '', '', '0', '1', '1', '0', '0', '', '', '1414012977', '1414174856', '1', '12', '');
INSERT INTO `onethink_fcoupon` VALUES ('5', '', '必胜客', '0', '0', '10', '50', '2xs1rdw0', '', '', '', '', '', '', '', '', '0', '0', '1', '0', '0', '', '', '1414174826', '1414174826', '1', '13', '');

-- -----------------------------
-- Table structure for `onethink_file`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_file`;
CREATE TABLE `onethink_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '远程地址',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- -----------------------------
-- Records of `onethink_file`
-- -----------------------------
INSERT INTO `onethink_file` VALUES ('1', 'yunwuxin-ThinkPay-master.zip', '5405e116b5a4e.zip', '2014-09-02/', 'zip', 'application/octet-stream', '23324', '1565d08c019b3958b1767bd8970f9f2c', '130d04a2ec9800243dc324b6ddce53f9c2c69e35', '0', '', '1409671446');
INSERT INTO `onethink_file` VALUES ('2', '14552934C-0.jpg', '5419eb9223a5f.jpg', '2014-09-18/', 'jpg', 'application/octet-stream', '206166', '66b8f2a751472d0de3b1c86c20be9949', '323183b6c93f2f5031daa8a47f2da0c3f362e3b7', '0', '', '1410984849');

-- -----------------------------
-- Table structure for `onethink_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_hooks`;
CREATE TABLE `onethink_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_hooks`
-- -----------------------------
INSERT INTO `onethink_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '', '1');
INSERT INTO `onethink_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop', '1');
INSERT INTO `onethink_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment', '1');
INSERT INTO `onethink_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment', '1');
INSERT INTO `onethink_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '', '1');
INSERT INTO `onethink_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment', '1');
INSERT INTO `onethink_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor', '1');
INSERT INTO `onethink_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin', '1');
INSERT INTO `onethink_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam', '1');
INSERT INTO `onethink_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor', '1');
INSERT INTO `onethink_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '', '1');
INSERT INTO `onethink_hooks` VALUES ('17', 'OTcaiji', 'OT采集插件钩子', '1', '1411634246', 'OTcaiji', '1');
INSERT INTO `onethink_hooks` VALUES ('22', 'indexAliPlay', '支付宝钩子', '1', '1412762558', 'indexAliPlay,AliPlay', '1');
INSERT INTO `onethink_hooks` VALUES ('19', 'J_China_City', '每个系统都需要的一个中国省市区三级联动插件。', '1', '1411636527', 'ChinaCity', '1');
INSERT INTO `onethink_hooks` VALUES ('20', 'J_iyo9Table', '向着要编辑的位置点击一下，访位置会变成一个可编辑的input标签，编辑好后，鼠标再点击空白地方，即可保存', '1', '1411636824', 'Iyo9Table', '1');
INSERT INTO `onethink_hooks` VALUES ('24', 'checkin', '签到', '1', '1395371353', '', '1');
INSERT INTO `onethink_hooks` VALUES ('21', 'Template', '模版管理插件钩子', '1', '1411637366', 'Template', '1');
INSERT INTO `onethink_hooks` VALUES ('23', 'SyncLogin', '第三方账号同步登陆', '1', '1412762818', 'SyncLogin', '1');

-- -----------------------------
-- Table structure for `onethink_iswork`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_iswork`;
CREATE TABLE `onethink_iswork` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `uid` varchar(225) CHARACTER SET utf8 NOT NULL,
  `time` varchar(225) DEFAULT NULL,
  `status` int(10) DEFAULT NULL COMMENT '1-未使用 2-已使用',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_iswork`
-- -----------------------------
INSERT INTO `onethink_iswork` VALUES ('18', '1', '14189089729', '1');
INSERT INTO `onethink_iswork` VALUES ('22', '1', '1414090388', '1');

-- -----------------------------
-- Table structure for `onethink_listtmp`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_listtmp`;
CREATE TABLE `onethink_listtmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8 NOT NULL,
  `url` text CHARACTER SET utf8 NOT NULL,
  `source` text CHARACTER SET utf8 NOT NULL,
  `sourceurl` text CHARACTER SET utf8 NOT NULL,
  `dates` int(10) NOT NULL,
  `st` int(1) NOT NULL,
  `zt` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- -----------------------------
-- Table structure for `onethink_login`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_login`;
CREATE TABLE `onethink_login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户UID',
  `type_uid` varchar(255) NOT NULL COMMENT '授权登陆用户名 第三方分配的appid',
  `type` char(80) NOT NULL COMMENT '登陆类型 qq|sina',
  `oauth_token` varchar(150) DEFAULT NULL COMMENT '授权账号',
  `oauth_token_secret` varchar(150) DEFAULT NULL COMMENT '授权密码',
  PRIMARY KEY (`login_id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `onethink_member`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_member`;
CREATE TABLE `onethink_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  `address` varchar(225) DEFAULT NULL,
  `cellphone` varchar(225) DEFAULT NULL,
  `position` varchar(225) DEFAULT NULL,
  `realname` varchar(225) DEFAULT NULL,
  `youbian` varchar(225) DEFAULT NULL,
  `lever` varchar(225) DEFAULT 'lv1 ',
  `iswors` int(10) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `onethink_member`
-- -----------------------------
INSERT INTO `onethink_member` VALUES ('1', '123', '30', '1900-00-00', '1010422715', '320', '73', '2130706433', '1413206453', '2130706433', '1414233241', '1', '5656', '56546', '5564', '5456', '', 'lv1', '');

-- -----------------------------
-- Table structure for `onethink_menu`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_menu`;
CREATE TABLE `onethink_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=150 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_menu`
-- -----------------------------
INSERT INTO `onethink_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('2', '内容', '0', '4', 'Article/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0', '1');
INSERT INTO `onethink_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('13', '回收站', '2', '0', 'article/recycle', '1', '', '内容', '0', '1');
INSERT INTO `onethink_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('16', '用户', '0', '5', 'User/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('17', '用户信息', '16', '0', 'User/index', '0', '', '用户管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用户', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('19', '用户行为', '16', '0', 'User/action', '0', '', '行为管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addaction', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editaction', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('23', '变更行为状态', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('27', '权限管理', '16', '0', 'AuthManager/index', '0', '', '用户管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('43', '扩展', '0', '6', 'Addons/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('44', '插件管理', '43', '1', 'Addons/index', '0', '', '扩展', '0', '1');
INSERT INTO `onethink_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('57', '钩子管理', '43', '2', 'Addons/hooks', '0', '', '扩展', '0', '1');
INSERT INTO `onethink_menu` VALUES ('58', '模型管理', '68', '3', 'Model/index', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('63', '属性管理', '68', '0', 'Attribute/index', '0', '网站属性配置。', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('68', '系统', '0', '2', 'Config/group', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('70', '配置管理', '68', '4', 'Config/index', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('75', '菜单管理', '68', '5', 'Menu/index', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('76', '导航管理', '68', '6', 'Channel/index', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('80', '分类管理', '68', '2', 'Category/index', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('86', '备份数据库', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0', '1');
INSERT INTO `onethink_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('90', '还原数据库', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0', '1');
INSERT INTO `onethink_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('93', '其他', '0', '5', 'other', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '0', '', '行为管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('108', '修改密码', '16', '0', 'User/updatePassword', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('109', '修改昵称', '16', '0', 'User/updateNickname', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('122', '数据列表', '58', '0', 'think/lists', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('135', '已发货订单', '131', '2', 'Ordertransport/index', '0', '', '订单管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('134', '优惠券', '131', '4', 'Fcoupon/index', '0', '', '优惠券管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('131', '订单', '0', '3', 'Order/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('132', '已提交订单', '131', '1', 'Order/index', '0', '', '订单管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('133', '已签收订单', '131', '3', 'Ordercomplete/index', '0', '', '订单管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('137', '正退货订单', '131', '6', 'Back/index', '0', '', '退货管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('141', '同意换货商品', '131', '10', 'Changeagree/index', '0', '', '换货管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('138', '同意退货订单', '131', '7', 'Backagree/index', '0', '', '退货管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('139', '已退货订单', '131', '8', 'Backover/index', '0', '', '退货管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('140', '正换货商品', '131', '9', 'Change/index', '0', '', '换货管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('142', '已换货商品', '131', '12', 'Changeover/index', '0', '', '换货管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('143', '今日销量统计', '146', '13', 'Statistics/index', '0', '', '数据统计', '0', '1');
INSERT INTO `onethink_menu` VALUES ('144', '本周销量统计', '146', '14', 'Statistics/week', '0', '', '数据统计', '0', '1');
INSERT INTO `onethink_menu` VALUES ('145', '本月销量统计', '146', '15', 'Statistics/month', '0', '', '数据统计', '0', '1');
INSERT INTO `onethink_menu` VALUES ('146', '数据', '0', '4', 'Statistics/index', '0', '', '数据统计', '0', '1');
INSERT INTO `onethink_menu` VALUES ('147', '每日数据', '146', '16', 'Report/index', '0', '', '报表统计', '0', '1');
INSERT INTO `onethink_menu` VALUES ('148', '每周数据', '146', '17', 'Report/week', '0', '', '报表统计', '0', '1');
INSERT INTO `onethink_menu` VALUES ('149', '每月统计', '146', '18', 'Report/month', '0', '', '报表统计', '0', '1');

-- -----------------------------
-- Table structure for `onethink_model`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_model`;
CREATE TABLE `onethink_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text NOT NULL COMMENT '属性列表（表的字段）',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text NOT NULL COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `onethink_model`
-- -----------------------------
INSERT INTO `onethink_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"2\",\"3\",\"5\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"16\",\"17\",\"19\",\"20\"]}', '1:基础', '', '', '', '', 'id:编号
title:标题:article/edit?cate_id=[category_id]&id=[id]
type:类型
update_time:最后更新
status:状态
view:浏览
id:操作:[EDIT]&cate_id=[category_id]|编辑,article/setstatus?status=-1&ids=[id]|删除', '0', '', '', '1383891233', '1413845425', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('2', 'article', '文章', '1', '', '1', '{\"1\":[\"3\",\"24\",\"2\",\"5\"],\"2\":[\"9\",\"13\",\"19\",\"10\",\"12\",\"16\",\"17\",\"26\",\"20\",\"14\",\"11\",\"25\"]}', '1:基础,2:扩展', '', '', '', '', '', '0', '', '', '1383891243', '1387260622', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('3', 'download', '下载', '1', '', '1', '{\"1\":[\"3\",\"28\",\"30\",\"32\",\"2\",\"5\",\"31\"],\"2\":[\"13\",\"10\",\"27\",\"9\",\"12\",\"16\",\"17\",\"19\",\"11\",\"20\",\"14\",\"29\"]}', '1:基础,2:扩展', '', '', '', '', '', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('5', 'product', '商品', '1', '', '1', '{\"1\":[\"3\",\"12\",\"36\",\"46\",\"44\",\"43\",\"37\",\"35\",\"39\"],\"2\":[\"2\",\"41\",\"40\",\"9\",\"10\",\"42\",\"13\",\"14\",\"5\",\"16\",\"20\",\"38\",\"11\",\"17\",\"19\"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号
title:标题:', '10', '', '', '1411375498', '1414177267', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('7', 'coupon', '优惠券', '1', '', '1', '{\"1\":[\"3\",\"45\",\"12\",\"5\",\"13\"],\"2\":[\"2\",\"11\",\"10\",\"19\",\"20\",\"17\",\"9\",\"14\",\"16\"]}', '1:基础,2:扩展', '', '', '', '', 'id：主键', '10', '', '', '1414002884', '1414003271', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `onethink_order`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_order`;
CREATE TABLE `onethink_order` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(225) DEFAULT NULL,
  `pricetotal` decimal(50,2) NOT NULL DEFAULT '0.00',
  `ptime` int(225) DEFAULT NULL,
  `status` varchar(225) NOT NULL DEFAULT '0' COMMENT '0-系统生成完成1-用户已提交订单2-3系统处理进入物流配送',
  `assistant` varchar(225) DEFAULT '无' COMMENT '操作人',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `uid` int(225) DEFAULT NULL,
  `shipprice` varchar(225) DEFAULT NULL,
  `display` int(12) DEFAULT '1',
  `isover` varchar(225) DEFAULT NULL,
  `ispay` int(11) DEFAULT NULL COMMENT '1在线支付未完成2在线支付完成3-货到付款',
  `total` decimal(50,2) DEFAULT NULL,
  `tool` varchar(225) DEFAULT NULL COMMENT '是否默认地址',
  `addressid` int(225) DEFAULT NULL,
  `toolid` varchar(225) DEFAULT NULL,
  `isdefault` int(11) NOT NULL,
  `info` varchar(225) DEFAULT NULL,
  `backinfo` varchar(225) DEFAULT NULL,
  `score` int(225) DEFAULT NULL,
  `codeid` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=873 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_order`
-- -----------------------------
INSERT INTO `onethink_order` VALUES ('740', 'DA248747805975427896', '11.00', '1414087501', '2', '无', '0', '1', '10', '1', '', '', '1.00', '', '31', '', '0', '', '', '', '');
INSERT INTO `onethink_order` VALUES ('862', 'DA256806849536282142', '120.00', '1414168085', '2', '1', '1414169729', '1', '10', '1', '', '', '20.00', '申通', '0', '', '0', '申通', '已发货', '', '');
INSERT INTO `onethink_order` VALUES ('863', 'DA256806986015782416', '0.00', '', '0', '无', '0', '1', '', '1', '', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `onethink_order` VALUES ('784', 'DA245031149482586202', '20.00', '1414151237', '1', '1', '1414169412', '1', '10', '1', '', '', '20.00', '', '0', '', '0', '发申通', '', '', '');
INSERT INTO `onethink_order` VALUES ('872', 'DA252900301632270373', '0.00', '', '0', '无', '0', '1', '', '1', '', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `onethink_order` VALUES ('869', 'DA257209184178395375', '0.00', '', '0', '无', '0', '1', '', '1', '', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `onethink_order` VALUES ('868', 'DA257209098646613528', '50.00', '1414172113', '0', '无', '0', '1', '0', '1', '', '1', '50.00', '', '31', '', '0', '', '等待支付', '', '');
INSERT INTO `onethink_order` VALUES ('864', 'DA257106814623856858', '0.00', '', '0', '无', '0', '1', '', '1', '', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `onethink_order` VALUES ('865', 'DA257106870056994187', '0.00', '', '0', '无', '0', '1', '', '1', '', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `onethink_order` VALUES ('866', 'DA257117493318508066', '20.00', '1414171183', '0', '无', '0', '1', '10', '1', '', '1', '10.00', '', '31', '', '0', '', '等待支付', '', '');
INSERT INTO `onethink_order` VALUES ('867', 'DA257117560583464012', '0.00', '', '0', '无', '0', '1', '', '1', '', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `onethink_order` VALUES ('855', 'DA245934804911830539', '120.00', '1414159367', '3', '1', '1414170831', '1', '10', '1', '', '', '10.00', '圆通', '0', '2131313', '0', '', '已完成', '', '');
INSERT INTO `onethink_order` VALUES ('871', 'DA252896763239822190', '0.00', '', '0', '无', '0', '1', '', '1', '', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `onethink_order` VALUES ('870', 'DA252896654645704196', '20.00', '1414229359', '1', '无', '0', '1', '10', '1', '', '1', '10.00', '', '31', '', '0', '', '等待支付', '', '');
INSERT INTO `onethink_order` VALUES ('858', 'DA245950041289390346', '49.68', '1414159521', '2', '1', '1414167780', '1', '10', '1', '', '', '40.00', '55555555555555', '0', '546464', '0', '', '已发货', '320', '');
INSERT INTO `onethink_order` VALUES ('860', 'DA246005833500535179', '19.68', '1414160559', '0', '无', '0', '1', '10', '1', '', '1', '10.00', '', '0', '', '0', '', '', '320', '');

-- -----------------------------
-- Table structure for `onethink_picture`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_picture`;
CREATE TABLE `onethink_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_picture`
-- -----------------------------
INSERT INTO `onethink_picture` VALUES ('1', '/Uploads/Picture/2014-09-02/5405e0f3b1705.png', '', '36d077267c76901835c07eb98f43647f', '0f7ce26261cb7a81dcfb14e057982ec60fa3a6e0', '1', '1409671411');
INSERT INTO `onethink_picture` VALUES ('2', '/Uploads/Picture/2014-09-18/5419eb4fec0c7.jpg', '', '5435a1dae36fafc2e544f2f78854fb29', 'd93a6e9869e7bf2fc17a533d3060ade8c88c40a9', '1', '1410984783');
INSERT INTO `onethink_picture` VALUES ('3', '/Uploads/Picture/2014-09-22/541f3d86103d3.jpg', '', '8e77701a8b49232f17d7f13d91d40693', '4dd3a9e9938d8890db37452b3abe6ff91ead531a', '1', '1411333508');
INSERT INTO `onethink_picture` VALUES ('4', '/Uploads/Picture/2014-09-22/541ff48c48dcf.jpg', '', 'e23489fd7e4dcc3dffaecbdef316bc97', '212c69983a3aaae6e379c68521523f847f5065fc', '1', '1411380364');
INSERT INTO `onethink_picture` VALUES ('5', '/Uploads/Picture/2014-09-27/5426973d68594.jpg', '', 'b1cc728f0903646228442f12afec0559', '2dbeabe21876fe2e489eeaf8e71f9de9c6465886', '1', '1411815228');
INSERT INTO `onethink_picture` VALUES ('6', '/Uploads/Picture/2014-09-28/54282d125f21a.jpg', '', 'da9f27eee154037434fbad74dc73430a', 'd3299248c9946cb94e7f5eeaaa7818fe750ad9de', '1', '1411919121');
INSERT INTO `onethink_picture` VALUES ('7', '/Uploads/Picture/2014-09-28/54282f255e437.jpg', '', '2e1205543c59f21e6317c2adf56a64ae', '1ad27e3a47c074ab9b7ed3b2d0aff5f8f848a17f', '1', '1411919653');
INSERT INTO `onethink_picture` VALUES ('8', '/Uploads/Picture/2014-09-29/54284e0bb791c.jpg', '', '314edb167e8e67abe5fadb9ecb56a5bb', 'b7a1cf4f226334a39db5fa7351e3c696d3d562b3', '1', '1411927563');
INSERT INTO `onethink_picture` VALUES ('9', '/Uploads/Picture/2014-09-29/5428505721fe3.jpg', '', '3a9cfc025a0b8ae90939d080b6b0b3da', 'f0e1654339c40d42da7037cae6b26cef1336570b', '1', '1411928151');
INSERT INTO `onethink_picture` VALUES ('10', '/Uploads/Picture/2014-09-29/542851809c5fe.jpg', '', 'b7e3396d129e2501f393c5fbb59080d5', '1961d4b5d20e1ac3d50000570535ca41b5fa8c44', '1', '1411928448');
INSERT INTO `onethink_picture` VALUES ('11', '/Uploads/Picture/2014-10-22/5447bf1b8a10a.jpg', '', '4182ad0929a3a535f11273c31a7fd16b', 'b36f727aada45dd67f8206b978c46afc4b1254e6', '1', '1413988123');
INSERT INTO `onethink_picture` VALUES ('12', '/Uploads/Picture/2014-10-23/54481f89ef4dc.gif', '', '40e797c3661da89e463bf739b819a4fd', 'bba0f04434413fb63c3e6d82fe74d0ece7b647bf', '1', '1414012809');
INSERT INTO `onethink_picture` VALUES ('13', '/Uploads/Picture/2014-10-25/544a986712125.jpg', '', '5332d06200bc87cbeddefea48859eb87', 'e2207e6f2b7f0d7c6f9392ab70eb99b6a14f473b', '1', '1414174821');
INSERT INTO `onethink_picture` VALUES ('14', '/Uploads/Picture/2014-10-25/544a994e1e338.jpg', '', 'ad1a25faa262cf395b42b4aa4aead8cf', 'e08dc9cbab906cbeea1e036deaf3b791d6db4f9e', '1', '1414175054');

-- -----------------------------
-- Table structure for `onethink_shaddress`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_shaddress`;
CREATE TABLE `onethink_shaddress` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `orderid` int(5) NOT NULL,
  `uid` int(5) NOT NULL,
  `detail` varchar(50) DEFAULT NULL,
  `ptime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- -----------------------------
-- Table structure for `onethink_shopcart`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_shopcart`;
CREATE TABLE `onethink_shopcart` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `goodid` int(5) NOT NULL,
  `uid` int(5) NOT NULL,
  `num` int(50) DEFAULT NULL,
  `ptime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=latin1;


-- -----------------------------
-- Table structure for `onethink_shoplist`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_shoplist`;
CREATE TABLE `onethink_shoplist` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `goodid` int(225) DEFAULT NULL,
  `num` int(50) DEFAULT NULL,
  `orderid` varchar(225) CHARACTER SET utf8 DEFAULT NULL COMMENT '订单号',
  `uid` int(225) DEFAULT NULL,
  `status` int(10) DEFAULT NULL COMMENT '默认null-未提交订单1-表示已提交订单或已支付2-已完成3-退货4-换货',
  `time` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=828 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_shoplist`
-- -----------------------------
INSERT INTO `onethink_shoplist` VALUES ('756', '8', '1', '740', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('757', '8', '1', '742', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('758', '8', '1', '744', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('759', '8', '1', '745', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('760', '8', '1', '747', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('761', '8', '1', '748', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('762', '8', '1', '750', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('763', '8', '1', '752', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('764', '8', '1', '754', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('765', '8', '1', '756', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('766', '8', '1', '758', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('767', '8', '1', '760', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('768', '8', '1', '762', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('769', '8', '1', '764', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('770', '8', '1', '766', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('771', '8', '1', '768', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('772', '8', '1', '770', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('773', '8', '1', '772', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('774', '8', '1', '774', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('775', '8', '1', '776', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('776', '8', '1', '778', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('777', '8', '1', '780', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('778', '8', '1', '782', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('779', '8', '1', '784', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('780', '9', '1', '786', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('781', '9', '1', '788', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('782', '9', '1', '790', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('783', '9', '1', '792', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('784', '9', '1', '794', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('785', '9', '1', '795', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('786', '9', '1', '796', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('787', '9', '1', '797', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('788', '9', '1', '798', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('789', '9', '1', '799', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('790', '9', '1', '800', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('791', '9', '1', '801', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('792', '9', '1', '802', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('793', '9', '1', '803', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('794', '9', '1', '805', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('795', '9', '1', '807', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('796', '9', '1', '809', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('797', '9', '1', '811', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('798', '9', '1', '813', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('799', '9', '1', '814', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('800', '9', '1', '816', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('801', '9', '1', '818', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('802', '5', '1', '820', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('803', '5', '1', '822', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('804', '5', '1', '824', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('805', '5', '1', '826', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('806', '5', '1', '828', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('807', '5', '1', '830', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('808', '5', '1', '832', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('809', '5', '1', '834', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('810', '5', '1', '836', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('811', '5', '1', '838', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('812', '5', '1', '840', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('813', '5', '1', '842', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('814', '5', '1', '844', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('815', '5', '1', '846', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('816', '5', '1', '848', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('817', '8', '1', '852', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('818', '8', '1', '854', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('819', '8', '1', '855', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('820', '8', '4', '858', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('821', '8', '1', '860', '', '', '');
INSERT INTO `onethink_shoplist` VALUES ('822', '8', '1', '862', '', '1', '');
INSERT INTO `onethink_shoplist` VALUES ('823', '8', '1', '864', '', '1', '');
INSERT INTO `onethink_shoplist` VALUES ('824', '8', '1', '866', '', '1', '');
INSERT INTO `onethink_shoplist` VALUES ('825', '8', '4', '868', '', '1', '');
INSERT INTO `onethink_shoplist` VALUES ('826', '9', '2', '868', '', '1', '');
INSERT INTO `onethink_shoplist` VALUES ('827', '8', '1', '870', '', '1', '');

-- -----------------------------
-- Table structure for `onethink_sync_login`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_sync_login`;
CREATE TABLE `onethink_sync_login` (
  `uid` int(11) NOT NULL,
  `openid` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `access_token` varchar(255) NOT NULL,
  `refresh_token` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- -----------------------------
-- Table structure for `onethink_transport`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_transport`;
CREATE TABLE `onethink_transport` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `orderid` int(5) NOT NULL,
  `cellphone` varchar(225) CHARACTER SET utf8 NOT NULL,
  `address` varchar(225) CHARACTER SET utf8 NOT NULL,
  `realname` varchar(225) CHARACTER SET utf8 NOT NULL,
  `time` int(10) DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_transport`
-- -----------------------------
INSERT INTO `onethink_transport` VALUES ('31', '731', '4564', '12345645', '456', '1414078290', '1', '1');
INSERT INTO `onethink_transport` VALUES ('32', '731', '4564', '12399999999999', '456', '', '', '1');
INSERT INTO `onethink_transport` VALUES ('33', '731', '4564', '12399999999999', '456', '', '', '1');
INSERT INTO `onethink_transport` VALUES ('34', '731', '4564', '12399999999999', '456', '', '', '1');
INSERT INTO `onethink_transport` VALUES ('35', '731', '4564', '12399999999999', '456', '1414079477', '', '');
INSERT INTO `onethink_transport` VALUES ('36', '731', '4564', '12399999999999', '456', '1414079805', '', '');
INSERT INTO `onethink_transport` VALUES ('37', '731', '4564', '12399999999999', '456', '1414079926', '', '');
INSERT INTO `onethink_transport` VALUES ('38', '731', '4564', '12399999999999', '456', '1414079936', '', '');
INSERT INTO `onethink_transport` VALUES ('39', '0', '', '999999', '', '1414080046', '1', '');
INSERT INTO `onethink_transport` VALUES ('40', '0', '654654', '999999', '564654654', '1414080095', '1', '');
INSERT INTO `onethink_transport` VALUES ('41', '0', '654654', '999999', '564654654', '1414080127', '1', '');
INSERT INTO `onethink_transport` VALUES ('42', '0', '654654', '999999', '564654654', '1414080136', '1', '');
INSERT INTO `onethink_transport` VALUES ('43', '0', '654654', '999999', '564654654', '1414080189', '1', '');
INSERT INTO `onethink_transport` VALUES ('44', '733', '654654', '999999', '564654654', '1414080277', '1', '');
INSERT INTO `onethink_transport` VALUES ('45', '735', '546464', '4564', '564', '1414080382', '1', '');
INSERT INTO `onethink_transport` VALUES ('46', '735', '546464', '4564', '564', '1414080384', '1', '');
INSERT INTO `onethink_transport` VALUES ('47', '735', '546464', '4564', '564', '1414080387', '', '');
INSERT INTO `onethink_transport` VALUES ('48', '735', '546464', '4564', '564', '1414080614', '', '');
INSERT INTO `onethink_transport` VALUES ('49', '735', '546464', '4564', '564', '1414080657', '1', '');
INSERT INTO `onethink_transport` VALUES ('50', '737', '', '9+99898', '99999999', '1414080707', '1', '');
INSERT INTO `onethink_transport` VALUES ('51', '737', '', '5555555555555', '99999999', '1414080736', '', '');
INSERT INTO `onethink_transport` VALUES ('52', '740', '56546', '5656', '5456', '1414087498', '1', '');

-- -----------------------------
-- Table structure for `onethink_turnover`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_turnover`;
CREATE TABLE `onethink_turnover` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(225) DEFAULT NULL,
  `sales` decimal(50,2) DEFAULT NULL,
  `back` decimal(50,2) DEFAULT NULL,
  `change` decimal(50,2) DEFAULT NULL,
  `profits` decimal(50,2) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `update_time` int(10) DEFAULT NULL,
  `status` int(225) DEFAULT NULL COMMENT '年月日的标示',
  `info` varchar(225) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_turnover`
-- -----------------------------
INSERT INTO `onethink_turnover` VALUES ('24', '1', '410.36', '30.00', '17.88', '362.48', '1414104925', '1414220166', '2', '43');
INSERT INTO `onethink_turnover` VALUES ('27', '1', '133.34', '20.00', '17.88', '95.46', '1414104975', '1414166156', '1', '20141024');
INSERT INTO `onethink_turnover` VALUES ('31', '1', '11.00', '30.00', '17.88', '-36.88', '1414137480', '1414137480', '3', '201410');
INSERT INTO `onethink_turnover` VALUES ('32', '1', '190.00', '', '', '190.00', '1414177041', '1414220426', '1', '20141025');

-- -----------------------------
-- Table structure for `onethink_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_admin`;
CREATE TABLE `onethink_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `onethink_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_app`;
CREATE TABLE `onethink_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `onethink_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_member`;
CREATE TABLE `onethink_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `onethink_ucenter_member`
-- -----------------------------
INSERT INTO `onethink_ucenter_member` VALUES ('1', '123', '46db58210048e61766852b1842cb4f0d', '14@qq.com', '1010422715', '1409671058', '2130706433', '1414233241', '2130706433', '1409671058', '1');

-- -----------------------------
-- Table structure for `onethink_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_setting`;
CREATE TABLE `onethink_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `onethink_url`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_url`;
CREATE TABLE `onethink_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `onethink_usercoupon`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_usercoupon`;
CREATE TABLE `onethink_usercoupon` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `uid` varchar(225) CHARACTER SET utf8 NOT NULL,
  `couponid` varchar(225) CHARACTER SET utf8 NOT NULL,
  `time` int(100) DEFAULT NULL,
  `status` int(10) DEFAULT NULL COMMENT '1-未使用 2-已使用',
  `cover_id` int(225) DEFAULT NULL COMMENT '图片',
  `info` varchar(225) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_usercoupon`
-- -----------------------------
INSERT INTO `onethink_usercoupon` VALUES ('7', '1', '5', '1414176060', '1', '', '未使用');
INSERT INTO `onethink_usercoupon` VALUES ('8', '1', '2', '1414176205', '1', '', '未使用');

-- -----------------------------
-- Table structure for `onethink_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_userdata`;
CREATE TABLE `onethink_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

